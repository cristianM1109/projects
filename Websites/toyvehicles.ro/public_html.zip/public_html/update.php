<?php
ob_start();
$id=$_GET["id"];

$dtb_err=0;
$conect_err=0;
$nofind_err=0;
$present=0;


$connect=mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
	$conect_err=1;
}

$sql = "SELECT titlu, pret, af ,km ,combustibil ,transmisie ,cm ,descriere,page,status,link,video_show,id FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sa gasit linia din tabel cu id=id
}
else{
	$nofind_err=1;
}

if ($result->num_rows > 0){
	$row = $result->fetch_assoc();
	
$titlu=$row['titlu'];
$pret=$row['pret'];
$af=$row['af'];
$km=$row['km'];
$comb=$row['combustibil'];
$trans=$row['transmisie'];
$cm=$row['cm'];
$link=$row['link'];
$desc=$row['descriere'];
$statu=$row['status'];
$show=$row['video_show'];
}

if($show == 1){
	$disp="<option"." selected "."value='Da'>Da</option>
                  <option value='Nu'>Nu</option>";
}
else{
	$disp="<option value='Da'>Da</option>
                  <option"." selected "."value='Nu'>Nu</option>";
}

if($comb == "Benzina"){
	$combustibil="<option"." selected "."value='Benzina'>Benzina</option>
                  <option value='Diesel'>Diesel</option>";
}
else{
	$combustibil="<option value='Benzina'>Benzina</option>
                  <option"." selected "."value='Diesel'>Diesel</option>";
}

if($trans == "Manual"){
	$transmisie="<option"." selected "."value='Manual'>Manual</option>
                  <option value='Automatic'>Automatic</option> ";
}
else{
	$transmisie="<option value='Manual'>Manual</option>
                  <option"." selected "."value='Automatic'>Automatic</option>";
}

if($statu == "Disponibil"){
	$st="<option"." selected "."value='Disponibil'>Disponibil</option>
                  <option value='Vandut'>Vandut</option>";
}
else{
	$st="<option value='Disponibil'>Disponibil</option>
                  <option"." selected "."value='Vandut'>Vandut</option>";
}


$sql = "SELECT page FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sa gasit linia din tabel cu id=id
}
else{
	$nofind_err=1;
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $page_addr=$row["page"];
}

if($show == 0){
	$var="ascunde";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Form</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='icon' href='assets/images/logoo.ico'>
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/css/util_form.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main_form.css">
<!--===============================================================================================-->

</head>
<style>
#button {
  background-color: transparent; /* Green */
  border: none;
  color: white;
  padding: 15px 56px;
  text-align: center;
  border-radius:24px;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

</style>
<body>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" enctype="multipart/form-data" method="post">
				<span class="contact100-form-title">
					Modifica Anunt
				</span>

				<div class="wrap-input100 validate-input" data-validate="Titlu is required">
					<span class="label-input100">Titlu</span>
					<input class="input100" type="text" name="Titlu" value="<?php echo $titlu; ?>" placeholder="Titlul anuntului">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Pret is required">
					<span class="label-input100">Pret</span>
					<input class="input100" type="text" name="Pret" value="<?php echo $pret;  ?>" placeholder="Pret">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "An fabricatie is required">
					<span class="label-input100">An fabricatie</span>
					<input class="input100" type="text" name="af" value="<?php echo  $af; ?>" placeholder="An fabricatie">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "Kilometraj is required">
					<span class="label-input100">Kilometraj</span>
					<input class="input100" type="text" name="Kilometri" value="<?php echo $km ; ?>" placeholder="Kilometraj">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Motor</span>
					<div>
						<select class="selection-2" name="Combustibil">
							<?php echo $combustibil; ?>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Transmisie</span>
					<div>
						<select class="selection-2" name="Transmisie">
							<?php echo $transmisie; ?>
							
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "Cm3 is required">
					<span class="label-input100">Capacitate motor(cm3)</span>
					<input class="input100" type="text" name="Cm3" value="<?php echo $cm ; ?>" placeholder="Cm3">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 input100-select">
					<span class="label-input100">Disponibilitate</span>
					<div>
						<select class="selection-2" name="Disponibilitate">
							<?php echo $st; ?>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				<div class="wrap-input100 validate-input" data-validate = "Descriere is required">
					<span class="label-input100">Descriere</span>
					<textarea class="input100" name="Descriere" placeholder="Your message here..."><?php echo $desc ; ?></textarea>
					<span class="focus-input100"></span>
				</div>
				<div class="wrap-input100 input100-select">
					<span class="label-input100">Afiseaza Video</span>
					<div>
						<select class="selection-2" name="Link_select" id="show" onchange="display_div()">
							<?php echo $disp; ?>
						</select>
					</div>
					<span class="focus-input100"></span>
				</div>
				<div class="wrap-input100 validate-input" id="link_active">
					<span class="label-input100">Link</span>
					<input class="input100" type="text" name="link" id="link" value="<?php echo $link ; ?>" placeholder="YouTube Link">
					<span class="focus-input100"></span>
				</div>
				
				
				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div>
						 <center><input type="submit" name="submit" value="Update"  id="button"/></center>
					</div>
				</div>
				<br><br>
				<center><a href="edit.php" class="btn btn-info" role="button"><i class="fa fa-angle-double-left"></i>  Inpoi la lista de anunturi</a></center><br>
				<center><a href="<?php echo $page_addr; ?>" class="btn btn-info" role="button"><i class="fa fa-angle-double-right"></i>  Vizualizeaza anunt</a></center>
			</form>
		</div>
	</div>



	<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
	<script src="assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/bootstrap/js/popper.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/select2/select2.min.js"></script>
	<script>
		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
		
 var x = document.getElementById("link_active");
 var show = document.getElementById("show").value;
 
 if (show === "Nu") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
 
		
 function display_div (e) {
 var show = document.getElementById("show").value;
 
 
 if (show === "Nu") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
 
 }
	</script>
<!--===============================================================================================-->
	<script src="assets/vendor/daterangepicker/moment.min.js"></script>
	<script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="assets/js/main_form.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

</body>
</html>

<?php 

$update_err=0;
$video_value=0;

if (isset( $_POST['submit'])){
$titlu=addslashes($_POST['Titlu']);
$pret=addslashes($_POST['Pret']);
$af=addslashes($_POST['af']);
$km=addslashes($_POST['Kilometri']);
$comb=addslashes($_POST['Combustibil']);
$trans=addslashes($_POST['Transmisie']);
$cm=addslashes($_POST['Cm3']);
$desc=addslashes($_POST['Descriere']);
$video=addslashes($_POST['Link_select']);
$link=addslashes($_POST['link']);
$statu=addslashes($_POST['Disponibilitate']);



if($video == "Da"){
	$ok=1;
}
else{
	$ok=0;
}

$query="UPDATE anunt SET titlu='$titlu',pret='$pret',af='$af',km='$km',combustibil='$comb',transmisie='$trans',cm='$cm',descriere='$desc',status='$statu' ,link='$link',video_show='$ok' WHERE id='$id'";

if(mysqli_query($connect, $query)){
   echo "<meta http-equiv='refresh' content='0'>";
} else{
    $update_err=1;
}

if($dtb_err == 1 || $conect_err == 1 || $nofind_err == 1 || $update_err == 1 ){
if($conect_err){
	$ms1="Nu se poate realiza conexiunea la baza de date!<br>";
    }
if($dtb_err){
	$ms2="Nu sa putut sterge informatiile din baza de date!<br>";
    }
if($nofind_err){
	$ms3="Nu sa gasit anuntul selectat!<br>";
    }
if($update_err){
	$ms4="Nu sa putut executa modifcarea bazei de date!<br>";
    }
	echo $dtb_err;
	echo $conect_err;
	echo $nofind_err;
	echo $update_err;
	
 header("location:error_up.php?ms1=$ms1&ms2=$ms2&ms3=$ms3&ms4=$ms4");
}
    
 

}
 ?>