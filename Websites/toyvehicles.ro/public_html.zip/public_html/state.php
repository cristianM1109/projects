<?php

session_start();

$redirect="login.php";
$state="Log In";
if(isset($_SESSION['user'])){
	$state="Settings";
	$redirect="logged.php";
}



 ?>