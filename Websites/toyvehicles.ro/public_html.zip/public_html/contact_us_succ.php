<?php
require_once("state.php");
 ?>

<!DOCTYPE html>
<!--[if IE 9]>
<html class="ie ie9" lang="en-US">
<![endif]-->
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <title>ToyVehicules</title>
	 
	 <link rel="icon" href="assets/images/logoo.ico">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- Slider Pro Css -->
	<link rel="stylesheet" href="assets/css/sliderPro.css">
	<!-- Owl Carousel Css -->
	<link rel="stylesheet" href="assets/css/owl-carousel.css">
	<!-- Flat Icons Css -->
	<link rel="stylesheet" href="assets/css/flaticon.css">
	<!-- Animated Css -->
	<link rel="stylesheet" href="assets/css/animated.css">
	<!-- Footer -->
	<link rel="stylesheet" href="assets/css/footer.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	<style>
	h10 {
  display: block;
  font-size: 2em;
  margin-top: 0.67em;
  margin-bottom: 0.67em;
  margin-left: 0;
  margin-right: 0;
  font-weight: bold;
  font-family: Arvo;
}
	</style>


	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

</head>
<body>

	
	
	<div class="preloader">
        <div class="preloader-bounce">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
	
	<div id="search">
	    <button type="button" class="close">×</button>
	    <form>
	        <input type="search" value="" placeholder="type keyword(s) here" />
	        <button type="submit" class="primary-button"><a href="#">Search <i class="fa fa-search"></i></a></button>
	    </form>
	</div>
	
	<header class="site-header wow fadeIn" data-wow-duration="1s">
		<div id="main-header" class="main-header">
			<div class="container clearfix">
				<div class="logo">
					<a href="index.php"></a>
				</div>
				<div id='cssmenu'>
					<ul>
					   	<li><a href='index.php'>Homepage</a></li>
					   	<li class='active'><a href='car_listing_sidebar.php'>Car Listing</a>
					   	</li>
					   <li><a href='contact_us.php'>Contact Us</a></li>
					   <li><a href='<?php echo $redirect; ?>'><?php echo $state; ?></a>
					   <li>
					   		<a href="#search"><i class="fa fa-search"></i></a>
					   </li>
					</ul>
				</div>
			</div>
		</div>
	</header>


	<div class="page-heading wow fadeIn" data-wow-duration="0.5s">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="heading-content-bg wow fadeIn" data-wow-delay="0.75s" data-wow-duration="1s">
						<div class="row">
							<div class="heading-content col-md-12">
								
								<h2>Success <em></em></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<section>
		<div class="contact-content wow fadeIn" data-wow-delay="0.5s" data-wow-duration="1s">
			<div class="container">
				<center><h2 style="font-size: 50px;"><em><br><br><br>Your message has been sent!<br><br><br></em></h2></center>
			</div>
		</div>
	</section>


	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-center text-md-center">
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Menu</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="car_listing_sidebar.php"><i class="fa fa-angle-double-right"></i>Car Listing</a></li>
						<li><a href="contact_us.php"><i class="fa fa-angle-double-right"></i>Contact</a></li>
						<li><a href='<?php echo $redirect; ?>'><i class="fa fa-angle-double-right"></i><?php echo $state; ?></a>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<br><br><br>
					 <div class="logoo">
						<img src="assets/images/logoo_f.png"></center>
						
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Contact Info</h5>
					<ul class="list-unstyled quick-links">
						<li><h2><i class="fa fa-map-marker" aria-hidden="true">  Govajdia, Hunedoara, DJ687F, 337241</i></h2></li>
						
						<li><a href='tel:+40 720 665-336'><i class="fa fa fa-phone"></i>+40 720 665-336</a></li>
						<br>
						<li><a href="mailto:toyvehicules@yahoo.com"><i class="fa fa-envelope"></i>toyvehicules@yahoo.com</a></li>
						<br>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/ToyVehicules-113197947478967"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="mailto:toyvehicules@yahoo.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="https://www.toyvehicules.com/">Toyvehicules</a></u> is a Registered limited liability company founded in 2020.</p>
					<p class="h6">©<a class="text-green ml-2" href="https://www.toyvehicules.com/" target="_blank">All right Reserved.</a></p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
	
	

	<script src="assets/js/jquery-1.11.0.min.js"></script>

	<!-- Slider Pro Js -->
	<script src="assets/js/sliderpro.min.js"></script>

	<!-- Slick Slider Js -->
	<script src="assets/js/slick.js"></script>

	<!-- Owl Carousel Js -->
    <script src="assets/js/owl.carousel.min.js"></script>

	<!-- Boostrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Boostrap Js -->
    <script src="assets/js/wow.animation.js"></script>

	<!-- Custom Js -->
    <script src="assets/js/custom.js"></script>

    <!-- Google Map -->
    <script src="https://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="assets/js/jquery.gmap3.min.js"></script>

	
    

</body>
</html>