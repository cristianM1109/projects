<?php 

if(!($connect=mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource"))){
	 die("Connection failed");
}

?>