<?php
require_once("state.php");
 ?>


<!DOCTYPE html>
<!--[if IE 9]>
<html class="ie ie9" lang="en-US">
<![endif]-->
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ToyVehicules</title>
	
	<link rel="icon" href="assets/images/logoo.ico">
	<link rel="shortcut icon" href="assets/images/logoo.ico">


	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- Slider Pro Css -->
	<link rel="stylesheet" href="assets/css/sliderPro.css">
	<!-- Owl Carousel Css -->
	<link rel="stylesheet" href="assets/css/owl-carousel.css">
	<!-- Flat Icons Css -->
	<link rel="stylesheet" href="assets/css/flaticon.css">
	<!-- Animated Css -->
	<link rel="stylesheet" href="assets/css/animated.css">
	<!-- Footer -->
	<link rel="stylesheet" href="assets/css/footer.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


		<style>
html body [data-ca3_iconfont="ETmodules"]::before {
    font-family: "ETmodules";
}
[data-ca3_icon]::before {
    font-weight: normal;
    content: attr(data-ca3_icon);
}

.ca3-scroll-down-arrow {
	background-image: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4iICJodHRwOi8vd3d3LnczLm9yZy9HcmFwaGljcy9TVkcvMS4xL0RURC9zdmcxMS5kdGQiPjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iQ2hldnJvbl90aGluX2Rvd24iIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDIwIDIwIiBmaWxsPSJ3aGl0ZSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHBhdGggZD0iTTE3LjQxOCw2LjEwOWMwLjI3Mi0wLjI2OCwwLjcwOS0wLjI2OCwwLjk3OSwwYzAuMjcsMC4yNjgsMC4yNzEsMC43MDEsMCwwLjk2OWwtNy45MDgsNy44M2MtMC4yNywwLjI2OC0wLjcwNywwLjI2OC0wLjk3OSwwbC03LjkwOC03LjgzYy0wLjI3LTAuMjY4LTAuMjctMC43MDEsMC0wLjk2OWMwLjI3MS0wLjI2OCwwLjcwOS0wLjI2OCwwLjk3OSwwTDEwLDEzLjI1TDE3LjQxOCw2LjEwOXoiLz48L3N2Zz4=);
	background-size: contain;
	background-repeat: no-repeat;
}

.ca3-scroll-down-link {
  cursor:pointer;
	height: 60px;
	width: 80px;
	margin: 0px 0 0 -32px;
	line-height: 60px;
	position: absolute;
	left: 50%;
	bottom: 0px;
	color: #FFF;
	text-align: center;
	font-size: 70px;
	z-index: 100;
	text-decoration: none;
	text-shadow: 0px 0px 3px rgba(0, 0, 0, 0.4);

	-webkit-animation: ca3_fade_move_down 2s ease-in-out infinite;
	-moz-animation:    ca3_fade_move_down 2s ease-in-out infinite;
	animation:         ca3_fade_move_down 2s ease-in-out infinite;
}


/*animated scroll arrow animation*/
@-webkit-keyframes ca3_fade_move_down {
  0%   { -webkit-transform:translate(0,-20px); opacity: 0;  }
  50%  { opacity: 1;  }
  100% { -webkit-transform:translate(0,20px); opacity: 0; }
}
@-moz-keyframes ca3_fade_move_down {
  0%   { -moz-transform:translate(0,-20px); opacity: 0;  }
  50%  { opacity: 1;  }
  100% { -moz-transform:translate(0,20px); opacity: 0; }
}
@keyframes ca3_fade_move_down {
  0%   { transform:translate(0,-20px); opacity: 0;  }
  50%  { opacity: 1;  }
  100% { transform:translate(0,20px); opacity: 0; }
}

#change_color{
	background-color: #e60000;
	
}

	</style>

</head>
<body>
	
	<div class="preloader">
        <div class="preloader-bounce">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
	
	<div id="search">
	    <button type="button" class="close">×</button>
	    <form>
	        <input type="search" value="" placeholder="type keyword(s) here" />
	        <button type="submit" class="primary-button">Search <i class="fa fa-search"></i></button>
	    </form>
	</div>
	
	<header class="site-header wow fadeIn" data-wow-duration="1s">
		<div id="main-header" class="main-header">
			<div class="container clearfix">
				<div class="logo">
					<a href="index.html"></a>
				</div>
				<div id='cssmenu'>
					<ul>
					   	<li><a href='index.php'>Homepage</a></li>
					   	<li class='active'><a href='car_listing_sidebar.php'>Car Listing</a>
					   	</li>
					   <li><a href='contact_us.php'>Contact Us</a></li>
					   <li><a href='<?php echo $redirect; ?>'><?php echo $state; ?></a>
					   <li>
					   		<a href="#search"><i class="fa fa-search"></i></a>
					   </li>
					</ul>
				</div>
			</div>
		</div>
	</header>
    <center><a id="scroll" class="ca3-scroll-down-link ca3-scroll-down-arrow" data-ca3_iconfont="ETmodules" data-ca3_icon=""></a></center>

	<div class="Modern-Slider">
	  <!-- Slide 1 -->
	  <div class="item">
	    <div class="img-fill">
	      <img src="assets/images/BD3hPCf.jpg" alt="">
	      <div class="info">
	        <div>
	        	<h5>Welcome </h5>
	          	<h3>TOYVEHICULES <em>SRL</em></h3>
	        </div>
	      </div>
	    </div>
	  </div>
	</div>



	<section class="top-slider-features wow fadeIn" data-wow-duration="1.5s">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="slider-top-features">
						<div id="owl-top-features" class="owl-carousel owl-theme">
								<?php
    $conn = mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT titlu, pret, af ,km ,combustibil ,transmisie ,cm ,descriere,page,status,id FROM anunt";
$result = $conn->query($sql);
$path="";


						
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		
		$id=$row["id"];
		$counter=$row["status"];
		
		$sql1 = "SELECT path FROM img_idx WHERE id=$id";
		$result1 = $conn->query($sql1);
		   if ($result1->num_rows > 0){
			     $row1 = $result1->fetch_assoc();
				 $path=$row1["path"];
				
		   }

		
        echo "<div class='item car-item'>
								<div class='thumb-content'>
									<a href='".$row["page"]."'><img src='idx_pho/".$path."' alt=''></a>
								</div>
								<div class='down-content'>
									<a href='".$row["page"]."'><h4>".$row["titlu"]."</h4></a>
									<span>€".$row["pret"]."</span>
								</div>
							</div>";
    }
}
$conn->close();


	?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="recent-cars">
			<div class="container">
				<div class="recent-car-content">
					<div class="row">
						<div class="col-md-12">
							<div class="section-heading">
								<div class="icon">
									<i class="fa fa-car"></i>
								</div>
								<div class="text-content">
									<h2>Recent Cars</h2>
									<span>Check our recent posts</span>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
													<?php
    $conn = mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT titlu, pret, af ,km ,combustibil ,transmisie ,cm ,descriere,page,status,id FROM anunt ORDER BY id DESC";
$result = $conn->query($sql);
$path="";


						
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		
		$id=$row["id"];
		$counter=$row["status"];
		
		$sql1 = "SELECT path FROM img_idx WHERE id=$id";
		$result1 = $conn->query($sql1);
		   if ($result1->num_rows > 0){
			     $row1 = $result1->fetch_assoc();
				 $path=$row1["path"];
				
		   }
		   
     if($counter == "Vandut"){
		  
		  $style="change_color";
		  
	  }
	else{
		$style="";
	}
		
        echo "<div class='col-md-4 col-sm-6'>
							<div class='car-item wow fadeIn' data-wow-duration='0.75s'>
								<div class='thumb-content'>
									<div class='car-banner'>
										<a href='".$row["page"]."'  id=\"".$style."\">".$row["status"]."</a>
									</div>
									<div class='thumb-inner'>
										<a href='".$row["page"]."'><img src='idx_pho/".$path."' alt=''></a>
									</div>
								</div>
								<div class='down-content'>
									<a href='".$row["page"]."'><h4>".$row["titlu"]."</h4></a>
									<span>€".$row["pret"]."</span>
									<ul class='car-info'>
										<li><div class='item'><i class='flaticon flaticon-calendar'></i><p>".$row["af"]."</p></div></li>
										<li><div class='item'><i class='flaticon flaticon-motor'></i><p>".$row["cm"]."</p></div></li>
										<li><div class='item'><i class='flaticon flaticon-road'></i><p>".$row["km"]." km</p></div></li>
										<li><div class='item'><i class='flaticon flaticon-fuel'></i><p>".$row["combustibil"]."</p></div></li>
									</ul>
								</div>
							</div>
						</div>";
    }
}
$conn->close();


	?>
						
					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-center text-md-center">
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Menu</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="car_listing_sidebar.php"><i class="fa fa-angle-double-right"></i>Car Listing</a></li>
						<li><a href="contact_us.php"><i class="fa fa-angle-double-right"></i>Contact</a></li>
						<li><a href='<?php echo $redirect; ?>'><i class="fa fa-angle-double-right"></i><?php echo $state; ?></a>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<br><br><br>
					 <div class="logoo">
						<img src="assets/images/logoo_f.png"></center>
						
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Contact Info</h5>
					<ul class="list-unstyled quick-links">
						<li><h2><i class="fa fa-map-marker" aria-hidden="true">  Govajdia, Hunedoara, DJ687F, 337241</i></h2></li>
						
						<li><a href='tel:+40 720 665-336'><i class="fa fa fa-phone"></i>+40 720 665-336</a></li>
						<br>
						<li><a href="mailto:toyvehicules@yahoo.com"><i class="fa fa-envelope"></i>toyvehicules@yahoo.com</a></li>
						<br>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/ToyVehicules-113197947478967"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="mailto:toyvehicules@yahoo.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="https://www.toyvehicules.com/">Toyvehicules</a></u> is a Registered limited liability company founded in 2020.</p>
					<p class="h6">©<a class="text-green ml-2" href="https://www.toyvehicules.com/" target="_blank">All right Reserved.</a></p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
	<script>
	const btn = document.getElementById('scroll');

btn.addEventListener('click', () => window.scrollTo({
  top: 700,
  behavior: 'smooth',
}));
	
	</script>

	<script src="assets/js/jquery-1.11.0.min.js"></script>

	<!-- Slider Pro Js -->
	<script src="assets/js/sliderpro.min.js"></script>

	<!-- Slick Slider Js -->
	<script src="assets/js/slick.js"></script>

	<!-- Owl Carousel Js -->
    <script src="assets/js/owl.carousel.min.js"></script>

	<!-- Boostrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Boostrap Js -->
    <script src="assets/js/wow.animation.js"></script>

	<!-- Custom Js -->
    <script src="assets/js/custom.js"></script>
	
	

</body>
</html>