<?php
require_once("state.php");
 ?>


<!DOCTYPE html>
<!--[if IE 9]>
<html class="ie ie9" lang="en-US">
<![endif]-->
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ToyVehicules</title>
	
	<link rel="icon" href="assets/images/logoo.ico">
	<link rel="shortcut icon" href="assets/images/logoo.ico">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- Slider Pro Css -->
	<link rel="stylesheet" href="assets/css/sliderPro.css">
	<!-- Owl Carousel Css -->
	<link rel="stylesheet" href="assets/css/owl-carousel.css">
	<!-- Flat Icons Css -->
	<link rel="stylesheet" href="assets/css/flaticon.css">
	<!-- Animated Css -->
	<link rel="stylesheet" href="assets/css/animated.css">
	<!-- Footer -->
	<link rel="stylesheet" href="assets/css/footer.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
   

     <link rel="stylesheet" href="assets/css/galery_style.css">
     <link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />
	
	<style>
	#button {
  background-color: red;
  box-shadow: 0 5px 0 darkred;
  color: white;
  padding: 0.5em 0.5em;
  position: relative;
  text-decoration: none;
}
#button:hover {
  background-color: #ce0606;
}

#button:active {
  box-shadow: none;
  top: 5px;
}

#change_color{
	background-color: #e60000;
	
}


	</style>

</head>

<body>

	
	
	
	
	<div id="search">
	    <button type="button" class="close">×</button>
	    <form>
	        <input type="search" value="" placeholder="type keyword(s) here" />
	        <button type="submit" class="primary-button"><a href="#">Search <i class="fa fa-search"></i></a></button>
	    </form>
	</div>
	
	<header class="site-header wow fadeIn" data-wow-duration="1s">
		<div id="main-header" class="main-header">
			<div class="container clearfix">
				<div class="logo">
					<a href="index.php"></a>
				</div>
				<div id='cssmenu'>
					<ul>
					   	<li><a href='index.php'>Homepage</a></li>
					   	<li class='active'><a href='car_listing_sidebar.php'>Car Listing</a>
					   	</li>
					   <li><a href='contact_us.php'>Contact Us</a></li>
					   <li><a href='<?php echo $redirect; ?>'><?php echo $state; ?></a>
					   <li>
					   		<a href="#search"><i class="fa fa-search"></i></a>
					   </li>
					</ul>
				</div>
			</div>
		</div>
	</header>


	<div class="page-heading wow fadeIn" data-wow-duration="0.5s">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="heading-content-bg wow fadeIn" data-wow-delay="0.75s" data-wow-duration="1s">
						<div class="row">
							<div class="heading-content col-md-12">
								<p><a href="index.php">Homepage</a> / <em> Cars</em> / <em> Listing</em></p>
								<h2>Cars <em>Listing</em></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="on-listing wow fadeIn" data-wow-delay="0.5s" data-wow-duration="1s">
		<div class="container">
			<div class="recent-car-content">
				<div class="row">
					<div class="col-md-8">
						<div class="row">
						<?php
						
						

$conn = mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT titlu, pret, af ,km ,combustibil  ,transmisie ,cm ,descriere,page,status,link,id FROM anunt ORDER BY id ASC";
$result = $conn->query($sql);
$path="";


						
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		
		$id=$row["id"];
		$counter=$row["status"];
		
		$sql1 = "SELECT path FROM img_idx WHERE id=$id";
		$result1 = $conn->query($sql1);
		   if ($result1->num_rows > 0){
			     $row1 = $result1->fetch_assoc();
				 $path=$row1["path"];
				
		   }
      
	  if($counter == "Vandut"){
		  
		  $style="change_color";
		  
	  }
	else{
		$style="";
	}
		
        echo "<div class='col-md-12'>
		       <div class='car-item'>
		         <div class='row'>
				    <div class='col-md-5'>
					     <div class='thumb-content'>
						       <div class='car-banner'>
							          <a href='".$row['page']."' id=\"".$style."\">". $counter. "</a>
									        </div>
											 <div class='thumb-inner'>
													<a href='".$row['page']."'><img src='title/".$path."'></a>
												</div>
											</div>
										</div>
										<div class='col-md-7'>
											<div class='down-content'>
												<a href='".$row['page']."'><h4>". $row["titlu"]. "</h4></a>
												<span>€" . $row["pret"] ."</span>
												<div class='line-dec'></div><br>
												<ul class='car-info'>
												<br><br><br>
													<li><div class='item'><i class='flaticon flaticon-calendar'></i><p>" .$row["af"]. "</p></div></li>
													<li><div class='item'><i class='flaticon flaticon-road'></i><p>" .$row["km"]." km</p></div></li>
													<li><div class='item'><i class='flaticon flaticon-fuel'></i><p>".$row["combustibil"]."</p></div></li>
													<li><div class='item'><i class='flaticon flaticon-motor'></i><p>".$row["cm"]."</p></div></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>";
    }
}
$conn->close();
?>
							
						</div>
					</div>
					<div class="col-md-4">
						<div class="sidebar-widgets">
							<div class="row">
								<div class="col-md-12">
									<div class="sidebar-widget">
										<div class="search-content">
											<div class="search-heading">
												<div class="icon">
													<i class="fa fa-search"></i>
												</div>
												<div class="text-content">
													<h2>Quick Search</h2>
													<span>We made a quick search just for you</span>
												</div>
											</div>
											<div class="search-form">
												<div class="row">
													<div class="col-md-12">
														<input type="text" onfocus="this.value=''" value="Type keywords...">
													</div>
						                            <div class="col-md-12">       
						                                <div class="input-select">
						                                    <select name="brand" id="brand">
						                                        <option value="-1">Select Brand</option>
						                                          <option>Toyota</option>
						                                    </select>
						                                </div>
						                            </div>
						                            <div class="col-md-6">       
						                                <div class="input-select">
						                                    <select name="min-price" id="min-price">
						                                        <option value="-1">Min Price</option>
						                                          <option>€500</option>
						                                          <option>€1.000</option>
						                                          <option>€1.500</option>
						                                          <option>€2.000</option>
						                                          <option>€2.500</option>
						                                    </select>
						                                </div>
						                            </div>
						                            <div class="col-md-6">       
						                                <div class="input-select">
						                                    <select name="max-price" id="max-price">
						                                        <option value="-1">Max Price</option>
						                                          <option>€5.000</option>
						                                          <option>€7.500</option>
						                                          <option>€10.000</option>
						                                          <option>€15.500</option>
						                                          <option>€20.000</option>
						                                    </select>
						                                </div>
						                            </div>
						                            <div class="col-md-12">       
						                                <div class="input-select">
						                                    <select name="fuel" id="fuel">
						                                        <option value="-1">Fuel Type</option>
						                                          <option>Gasoline</option>
						                                          <option>Diesel</option>
						                                    </select>
						                                </div>
						                            </div>
						                            <div class="col-md-12">       
						                                <div class="input-select">
						                                    <select name="transmission" id="transmission">
						                                        <option value="-1">Transmission Type</option>
						                                          <option>Automatic</option>
						                                          <option>Manual</option>
						                                    </select>
						                                </div>
						                            </div>
						                            <div class="col-md-12">
						                            	<div class="secondary-button">
						                            		<a href="#">Search <i class="fa fa-search"></i></a>
						                            	</div>
						                            </div>
						                        </div>
						                    </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-center text-md-center">
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Menu</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="car_listing_sidebar.php"><i class="fa fa-angle-double-right"></i>Car Listing</a></li>
						<li><a href="contact_us.php"><i class="fa fa-angle-double-right"></i>Contact</a></li>
						<li><a href='<?php echo $redirect; ?>'><i class="fa fa-angle-double-right"></i><?php echo $state; ?></a>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<br><br><br>
					 <div class="logoo">
						<img src="assets/images/logoo_f.png"></center>
						
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Contact Info</h5>
					<ul class="list-unstyled quick-links">
						<li><h2><i class="fa fa-map-marker" aria-hidden="true">  Govajdia, Hunedoara, DJ687F, 337241</i></h2></li>
						
						<li><a href='tel:+40 720 665-336'><i class="fa fa fa-phone"></i>+40 720 665-336</a></li>
						<br>
						<li><a href="mailto:toyvehicules@yahoo.com"><i class="fa fa-envelope"></i>toyvehicules@yahoo.com</a></li>
						<br>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="https://www.facebook.com/ToyVehicules-113197947478967"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="mailto:toyvehicules@yahoo.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="https://www.toyvehicules.com/">Toyvehicules</a></u> is a Registered limited liability company founded in 2020.</p>
					<p class="h6">©<a class="text-green ml-2" href="https://www.toyvehicules.com/" target="_blank">All right Reserved.</a></p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
	
	
        <script type="text/javascript" src="jquery/jquery-3.6.0.min.js"></script>
		<script src="assets/js/custom.js"></script>
		 <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script type="text/javascript" src="venobox/venobox.min.js"></script>
		<script>
            $(document).ready(function(){
                $('.venobox').venobox({
                    closeColor: '#f4f4f4',
                    spinColor: '#f4f4f4',
                    arrowsColor: '#f4f4f4',
                    closeBackground: '#17191D',
                    overlayColor: 'rgba(23,25,29,0.8)'
                }); 
            });
        </script>

	<!-- Slider Pro Js -->
	<script src="assets/js/sliderpro.min.js"></script>

	<!-- Slick Slider Js -->
	<script src="assets/js/slick.js"></script>

	<!-- Owl Carousel Js -->
    <script src="assets/js/owl.carousel.min.js"></script>

	<!-- Boostrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Boostrap Js -->
    <script src="assets/js/wow.animation.js"></script>

	<!-- Custom Js -->
    

</body>
</html>