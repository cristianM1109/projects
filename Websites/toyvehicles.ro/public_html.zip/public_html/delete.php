<!DOCTYPE html>
<html lang="en">
<head>
	<title>Database</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="assets/images/logoo.ico">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/css/util_t.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main_t.css">
<!--===============================================================================================-->

<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('ESTI SIGUR CA VREI SA STERGI ANUNTUL?');
}
</script>

</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<br><br>
				<div class="table100">
					<table>
						<thead>
							<tr class="table100-head">
								<th class="column1">Titlu</th>
								<th class="column2">Pret</th>
								<th class="column3">An fabriactie</th>
								<th class="column4">Status</th>
								<th class="column5">Tip Motor</th>
								<th class="column6">Sterge Anunt</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
$conn = mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT titlu, pret, af ,status,combustibil,id FROM anunt";
$result = $conn->query($sql);

						
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		
$titlu=$row["titlu"];
$pret=$row["pret"];
$af=$row["af"];
$status=$row["status"];
$comb=$row["combustibil"];
$id=$row["id"];
				
				
		
        echo "<tr>
									<td class='column1'>".$titlu."</td>
									<td class='column2'>".$pret."</td>
									<td class='column3'>".$af."</td>
									<td class='column4'>".$status."</td>
									<td class='column5'>".$comb."</td>
									<td class='column6'>"."<a href='del_script.php?id=$id' onclick=\"return checkDelete()\" class=\"btn btn-danger\" role=\"button\"><i class=\"fa fa-trash-o fa-lg\"></i>  Sterge</a></td>
									
			 </tr>";
    }
}
$conn->close();
						
						?>
								
								
						</tbody>
					</table>
					<br><br>
					<center><a href="logged.php" class="btn btn-info" role="button"><i class="fa fa-angle-double-left"></i>  Back to Menu</a></center>
				</div>
			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/bootstrap/js/popper.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="assets/js/main_t.js"></script>

</body>
</html>