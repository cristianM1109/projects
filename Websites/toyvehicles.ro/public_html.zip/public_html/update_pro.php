<?php

require_once("smart_resize_image.function.php");

$id=$_GET["id"];
$name=$_GET["name"];

$conn = mysqli_connect("188.241.222.216","toyvehic_user","Powervalve00*","toyvehic_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT path FROM img_idx WHERE id='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$old=$row["path"];
    unlink("idx_pho/".$old);
    unlink("title/".$old);
}

$query="UPDATE img_idx SET path='$name' WHERE id='$id'";

if(mysqli_query($conn, $query)){
	
   smart_resize_image("upload/".$name , null, 370 , 345 , false , "title/".$name , false , false ,80 );
   smart_resize_image("upload/".$name , null, 370 , 260 , false , "idx_pho/".$name , false , false ,80 );
				
} else{
    $update_err=1;
}
$vid="";
header("Location:galery_menu.php?id=$id&err=$vid");
?>