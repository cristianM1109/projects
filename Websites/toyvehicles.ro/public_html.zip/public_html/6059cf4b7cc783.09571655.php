<?php require_once("state.php"); require_once("conection.php");$id=96;$sql = "SELECT titlu, pret, af ,km ,combustibil ,transmisie ,cm ,descriere,link,video_show,id FROM anunt where id=$id";$result = $connect->query($sql);$path="";if ($result->num_rows > 0) {$row = $result->fetch_assoc();$titlu=$row["titlu"];$pret=$row["pret"];$af=$row["af"];$comb=$row["combustibil"];$link=$row["link"];$km=$row["km"];$ok=$row["video_show"];$trans=$row["transmisie"];$cm=$row["cm"];$desc1=$row["descriere"];$desc=nl2br($desc1);}?>
<!DOCTYPE html>
<html lang='en-US'>
   <head>
      <meta charset='UTF-8'>
      <meta name='description' content=''>
      <meta name='keywords' content='HTML,CSS,XML,JavaScript'>
      <meta name='viewport' content='width=device-width, initial-scale=1.0'>
      <title>ToyVehicules</title>
      <link rel='icon' href='assets/images/logoo.ico'>
      <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
      <link rel='stylesheet' type='text/css' href='assets/css/lightbox.min.css'>
      <link rel='stylesheet' href='assets/css/bootstrap.css'>
      <link rel='stylesheet' href='assets/css/font-awesome.min.css'>
      <link rel='stylesheet' href='assets/css/main.css'>
      <!-- Slider Pro Css -->
      <link rel='stylesheet' href='assets/css/sliderPro.css'>
      <!-- Owl Carousel Css -->
      <link rel='stylesheet' href='assets/css/owl-carousel.css'>
      <!-- Flat Icons Css -->
      <link rel='stylesheet' href='assets/css/flaticon.css'>
      <!-- Animated Css -->
      <link rel='stylesheet' href='assets/css/animated.css'>
      <!-- Footer -->
      <link rel="stylesheet" href="assets/css/footer.css">
      
     <link rel="stylesheet" href="assets/css/galery_style.css">
     <link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="screen" />  
	 
	    <style>
	#button {
  background-color: red;
  box-shadow: 0 5px 0 darkred;
  color: white;
  padding: 0.5em 0.5em;
  position: relative;
  text-decoration: none;
}
#button:hover {
  background-color: #ce0606;
}

#button:active {
  box-shadow: none;
  top: 5px;
}

	</style>

  </head>
   <body>
      <div id='search'>
         <button type='button' class='close'>×</button>
         <form><input type='search' value='' placeholder='type keyword(s) here' /><button type='submit' class='primary-button'><a href='#'>Search <i class='fa fa-search'></i></a></button></form>
      </div>
      <header class='site-header wow fadeIn' data-wow-duration='1s'>
         <div id='main-header' class='main-header'>
            <div class='container clearfix'>
               <div class='logo'><a href='index.php'></a></div>
               <div id='cssmenu'>
                  <ul>
                     <li><a href='index.php'>Homepage</a></li>
                     <li class='active'><a href='car_listing_sidebar.php'>Car Listing</a></li>
                     <li><a href='contact_us.php'>Contact Us</a></li>
                     <li><a href='<?php echo $redirect; ?>'><?php echo $state; ?></a>
                     <li><a href='#search'><i class='fa fa-search'></i></a></li>
                  </ul>
               </div>
            </div>
         </div>
      </header>
      <div class='page-heading wow fadeIn' data-wow-duration='0.5s'>
         <div class='container'>
            <div class='row'>
               <div class='col-md-12'>
                  <div class='heading-content-bg wow fadeIn' data-wow-delay='0.75s' data-wow-duration='1s'>
                     <div class='row'>
                        <div class='heading-content col-md-12'>
                           <p><a href='index.php'>Homepage</a> / <em> Cars</em> / <em> Car Details</em></p>
                           <h2>Car <em>Details</em></h2>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class='recent-car single-car wow fadeIn' data-wow-delay='0.5s' data-wow-duration='1s'>
         <div class='container'>
            <div class='recent-car-content'>
               <div class='row'>
                  <div class='col-md-6'>
                     <div id='single-car' class='slider-pro'>
                        <div class='sp-slides'>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4eecc2b1.14362696.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4f5b2f34.05694016.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4fbce657.39963379.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4e894138.88186304.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4e255311.08505800.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4db86212.41909858.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4b7da3a1.86882960.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4c1cb229.03447836.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4c824753.31167916.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4ce83dd2.95930102.jpeg' alt='' /></a></div>
                           <div class='sp-slide'><a href='galery.php?id=<?php echo $id;?>'><img class='sp-image' src='upload/6059cf4d576478.39255739.jpeg' alt='' /></a></div>
                        </div>
                        <div class='sp-thumbnails'><img class='sp-thumbnail' src='upload/6059cf4eecc2b1.14362696.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4f5b2f34.05694016.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4fbce657.39963379.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4e894138.88186304.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4e255311.08505800.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4db86212.41909858.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4b7da3a1.86882960.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4c1cb229.03447836.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4c824753.31167916.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4ce83dd2.95930102.jpeg' alt='' /><img class='sp-thumbnail' src='upload/6059cf4d576478.39255739.jpeg' alt='' /></div>
                     </div>
                  </div>
                  <div class='col-md-6'>
                     <div class='car-details'>
                        <h4><?php echo $titlu; ?></h4>
                        <span>€<?php echo $pret; ?></span>
                        <div class='container'>
                           <div class='row'>
                              <ul class='car-info col-md-6'>
                                 <li>
                                    <i class='flaticon flaticon-calendar'></i>
                                    <p><?php echo $af; ?></p>
                                 </li>
                                 <li>
                                    <i class='flaticon flaticon-road'></i>
                                    <p><?php echo $km; ?>km</p>
                                 </li>
                                 <li>
                                    <i class='flaticon flaticon-fuel'></i>
                                    <p><?php echo $comb; ?></p>
                                 </li>
                              </ul>
                              <ul class='car-info col-md-6'>
                                 <li>
                                    <i class='flaticon flaticon-shift'></i>
                                    <p><?php echo $trans; ?></p>
                                 </li>
                                 <li>
                                    <i class='flaticon flaticon-motor'></i>
                                    <p><?php echo $cm; ?></p>
                                 </li>
                              </ul>
                           </div>
                        </div>
                        <div id="hide">
						 <h10 style="color: #b48608; font-family: 'Droid serif', serif; font-size: 18px; font-weight: 700;">Watch restauration of this car on</h10><br>
                           <br><input style="display:none;" value='<?php echo $ok; ?>' id='show_hide'><a href='<?php echo $link; ?>' class="venobox" id='button' data-autoplay="true" data-vbtype="video"><i class="fa fa-video-camera"></i>  YouTube</a>
						</div>
                        <div class='similar-info'>
						<br><br><br><div class='primary-button'><a href='tel:+40 720 665-336'>Call<i class='fa fa-euro-sign'></i></a></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section>
         <div class='more-details'>
            <div class='container'>
               <div class='row'>
                  <div class='col-md-6'>
                     <div class='item wow fadeInUp' data-wow-duration='0.5s'>
                        <div class='sep-section-heading'>
                           <h2>More <em>Description</em></h2>
                        </div>
                        <p><?php echo $desc; ?></p>
                     </div>
                  </div>
                  <div class='col-md-6 wow fadeInUp' data-wow-duration='0.75s'>
                     <div class='item'>
                        <div class='sep-section-heading'>
                           <h2>Contact <em>Informations</em></h2>
                        </div>
                        <p>You can contact us by phone or email !</p>
                        <div class='contact-info'>
                           <div class='row'>
                              <div class='phone col-md-12 col-sm-6 col-xs-6'><a href='tel:+40 720 665-336'><i class='fa fa-phone'></i><span>+40 720 665-336</span></a></div>
                              <div class='mail col-md-12 col-sm-6 col-xs-6'><a href = 'mailto:toyvehicules@yahoo.com'><i class='fa fa-envelope'></i><span>toyvehicules@yahoo.com</span></a></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="footer">
         <div class="container">
            <div class="row text-center text-xs-center text-sm-center text-md-center">
               <div class="col-xs-12 col-sm-4 col-md-4">
                  <br><br>
                  <h5>Menu</h5>
                  <ul class="list-unstyled quick-links">
                     <li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
                     <li><a href="car_listing_sidebar.php"><i class="fa fa-angle-double-right"></i>Car Listing</a></li>
                     <li><a href="contact_us.php"><i class="fa fa-angle-double-right"></i>Contact</a></li>
                     <li><a href='<?php echo $redirect; ?>'><i class="fa fa-angle-double-right"></i><?php echo $state; ?></a>
                  </ul>
               </div>
               <div class="col-xs-12 col-sm-4 col-md-4">
                  <br><br><br>
                  <div class="content" style="sposition:absolute; width:100%; height:100%">
                     <center><img src="assets/images/logoo_f.png" style="display: block; margin: 0 auto;"></center>
                     <br>
                  </div>
               </div>
               <div class="col-xs-12 col-sm-4 col-md-4">
                  <br><br><br>
                  <h5>Contact Info</h5>
                  <ul class="list-unstyled quick-links">
                     <li>
                        <h2><i class="fa fa-map-marker" aria-hidden="true">  Govajdia, Hunedoara, DJ687F, 337241</i></h2>
                     </li>
                     <li><a href="tel:+40 720 665-336"><i class="fa fa fa-phone"></i>+40 720 665-336</a></li>
                     <br>
                     <li><a href="mailto:toyvehicules@yahoo.com"><i class="fa fa-envelope"></i>toyvehicules@yahoo.com</a></li>
                     <br>
                  </ul>
               </div>
            </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
                  <ul class="list-unstyled list-inline social text-center">
                     <li class="list-inline-item"><a href="https://www.facebook.com/ToyVehicules-113197947478967"><i class="fa fa-facebook"></i></a></li>
                     <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
                     <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                     <li class="list-inline-item"><a href="mailto:toyvehicules@yahoo.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
                  </ul>
               </div>
               <hr>
            </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                  <p><u><a href="https://www.toyvehicules.com/">Toyvehicules</a></u> is a Registered limited liability company founded in 2020.</p>
                  <p class="h6">©<a class="text-green ml-2" href="https://www.toyvehicules.com/" target="_blank">All right Reserved.</a></p>
               </div>
               <hr>
            </div>
         </div>
      </section>
	   <script type="text/javascript" src="jquery/jquery-3.6.0.min.js"></script>
        <script type="text/javascript" src="venobox/venobox.min.js"></script>
		<script>
            $(document).ready(function(){
                $('.venobox').venobox({
                    closeColor: '#f4f4f4',
                    spinColor: '#f4f4f4',
                    arrowsColor: '#f4f4f4',
                    closeBackground: '#17191D',
                    overlayColor: 'rgba(23,25,29,0.8)'
                }); 
            });
			
			 var show = document.getElementById("show_hide").value;
			 var x = document.getElementById("hide");
			 
			 if (show === "0") {
              x.style.display = "none";
  } 
  
			
        </script>
      <!-- Slider Pro Js --><script src='assets/js/sliderpro.min.js'></script><!-- Slick Slider Js --><script src='assets/js/slick.js'></script><!-- Owl Carousel Js --><script src='assets/js/owl.carousel.min.js'></script><!-- Boostrap Js --><script src='assets/js/bootstrap.min.js'></script><!-- Boostrap Js --><script src='assets/js/wow.animation.js'></script><!-- Custom Js --><script src='assets/js/custom.js'></script>
   </body>
</html>