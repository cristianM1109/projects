<?php  
$ms1=$_GET["ms1"];
$ms2=$_GET["ms2"];
$ms3=$_GET["ms3"];
$ms4=$_GET["ms4"];
$ms5=$_GET["ms5"];
$ms6=$_GET["ms6"];

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="assets/images/logoo.ico">
	
	<title>404 ERROR</title>

	<link href="https://fonts.googleapis.com/css?family=Cabin:400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">

	<link type="text/css" rel="stylesheet" href="assets/css/vaca.css" />

	
</head>
<style>
 h4{
	 font-family: Arial, Helvetica, Arial, sans-serif;
	 color:red;
 }

</style>

<body>

	<div id="notfound">
		<div class="notfound">
			<div class="notfound-404">
				<h3>Oops! Something went wrong</h3>
				<h1><span>4</span><span>0</span><span>4</span></h1>
			</div>
			<h2>we are sorry, something went wrong during upload , please try again!</h2>
			<h4>Aveti urmatoarele erori:</h4>
			<h4><?php echo $ms1; ?></h4>
			<h4><?php echo $ms2; ?></h4>
			<h4><?php echo $ms3; ?></h4>
			<h4><?php echo $ms4; ?></h4>
			<h4><?php echo $ms5; ?></h4>
			<h4><?php echo $ms6; ?></h4>
			<h2><a href="form.html"><i class="fa fa-angle-double-right"></i>Go to form</a></h2>
		</div>
	</div>

</body>

</html>
