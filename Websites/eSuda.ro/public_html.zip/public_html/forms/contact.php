<?php



 require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

use PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

if($_SERVER['REQUEST_METHOD'] === 'POST') {

$name=$_POST["name"];
$from=$_POST["email"];
$subj=$_POST["subject"];
$msg=$_POST["message"];

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer\PHPMailer();

try {
    //Server settings
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'glc21.hostico.ro';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'contact@e-suda.ro';                     //SMTP username
    $mail->Password   = 'sudaelectric';                               //SMTP password
    $mail->SMTPSecure = PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom($from, $name);
    $mail->addAddress("contact@e-suda.ro");     //Add a recipient
    $mail->addReplyTo($from, $name);


    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subj;
    $mail->Body    = '<b>'.$msg.'</b>'.'<br><br>'.'Email contact: '.$from;
    $mail->AltBody = $msg;

    $mail->send();
    echo 'OK';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
} 


}


?>