(function () {
    var tables = $("table");
    tables.hide().first().show();
    $("a.button").on("click", function () {
        tables.hide();
        var tableTarget = $(this).data("table");
        $("table#" + tableTarget).show();

    })
})();
