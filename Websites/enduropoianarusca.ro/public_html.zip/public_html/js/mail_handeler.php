<?php
require_once("Mail.php");

$emaill="registration2024@enduropoianarusca.ro";
$replyto = "no-reply@enduropoianarusca.com";
$to = "HEPR Receive Rgs < ".$emaill." > ";
$subject = "Registration HEPR 2024";
$mailer = 'PHP/' . phpversion();



$nameErr = $emailErr = $classErr = $telErr =$state= $clsErr = $vrsErr = $rdiErr = $lclErr=$cndErr=$cecErr= $motoerr = "";
$namee = $email = $class = $vrs = $rdi = $lcl = $cnd =$tel=$cls=$vrs= $obs=$lcl = "";
    $succses="";

function test_input($data)
    {
        $data=trim($data);
        $data=stripslashes($data);
        $data=htmlspecialchars($data);
        return $data;
    }

if($_SERVER["REQUEST_METHOD"] == "POST") {


  if (empty($_POST["Nume"])) {
    $nameErr = "NAME NOT COMPLETED!<br><br>";
  } else {
        $namee = test_input($_POST["Nume"]);
  }

if (empty($_POST["Club/Sponsor"])) {
    $classErr = "CLUB/SPONSOR NOT COMPLETED!<br><br>";
  }
else
{
    $class = test_input($_POST["Club/Sponsor"]);
}

if (empty($_POST["email"])) {
    $emailErr = "EMAIL ADDRESS NOT COMPLETED!<br><br>";
  } else {
    $email = test_input($_POST["email"]);
    if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
    $emailErr = "EMAIL INVALID FORMAT!<br><br>";
}
}

    if (empty($_POST["Telefon"])) {
    $telErr = "TELEPHONE NOT COMPLETED!<br><br>";
  } else {
    $tel = test_input($_POST["Telefon"]);
     if (!preg_match('/^[0-9]*$/', $tel)) {
    $telErr = "INVALID FORMAT!<br><br>";
}
}
    if(!empty($_POST['sel'])) {
  $state = $_POST['sel'];
  $clsErr="";
}
else {
  $clsErr="CATEGORY NOT SELECTED!<br><br>";
}

     if (empty($_POST["Varsta"])) {
    $vrsErr = "AGE NOT COMPLETED<br><br>";
  } else {
    $vrs = test_input($_POST["Varsta"]);
     if (!preg_match('/^[0-9]*$/', $vrs)) {
    $vrsErr = "INVALID FORMAT!<br><br>";
}
}
     

    if (empty($_POST["Localitate"])) {
    $lclErr = "COUNTRY AND CITY NOT COMPLETED!<br><br>";
  } else {
         $lcl = test_input($_POST["Localitate"]);
}
    
	if (empty($_POST["Mesaj"])) {
		
  } else {
         $obs = test_input($_POST["Mesaj"]);
}
	
	
}
if(isset($_POST["submit"]))
if($nameErr == '' and $classErr==''and $emailErr==''and $telErr==''and $clsErr=='' and $vrsErr=='' and $lclErr=='' and $cecErr=='')
{
    $body = "";
    unset($_POST["submit"]);

        $from = "Registration HEPR 2024 <registration2024@enduropoianarusca.ro>";


    $body .= "Nume: " . $namee ."<br>";
    $body .= "Clasa: " . $state ."<br>";
    $body .= "Varsta: " . $vrs ."<br>";
    $body .= "Localitate: " . $lcl ."<br>";
    $body .= "Club: " . $class ."<br>";
    $body .= "Email: " . $email ."<br>";
    $body .= "Telefon: " . $tel ."<br>";
    $body .= "Observatii: " . $obs ."<br>";

$aux=$namee;
$aux2=$email;
$namee =$state= $email = $class = $vrs = $rdi = $lcl = $cnd =$tel=$cls=$obs = "";
    $succses="";


$host = "mail.enduropoianarusca.ro";
$username = "registration2024@enduropoianarusca.ro";
$password = "poianarusca300";

$subject = $aux;

$headers = array(
     'From' => $from,
     'Reply-To' => $replyto,
     'Subject' => $subject,
     'MIME-Version' => "1.0",
     'To' => $to,
     'Content-type' => 'text/html; charset=UTF-8');


$smtp = Mail::factory('smtp', array ('host' => $host,
                                     'port' => '25',
                                     'auth' => true,
                                     'username' => $username,
                                     'password' => $password));


$emaill="registration2024@enduropoianarusca.ro";
$to = "HEPR < ".$emaill." > ";

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {

    $succses="Eroare,Incercati din nou";
 }
else
{
    $succses="Cerere inregistrata.Un email de confirmare a fost trimis la adresa specificata!";
}

    $to = "Inscriere HEPR < ".$aux2." > ";
    $replyto = "registration2024@enduropoianarusca.ro";

    $headers = array(
     'From' => $from,
     'Reply-To' => $replyto,
     'Subject' => $subject,
     'MIME-Version' => "1.0",
     'To' => $to,
     'Content-type' => 'text/html; charset=iso-8859-1');

    $body="<!DOCTYPE html>
<html>
<head>
<title></title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
<style type=\"text/css\">

body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
img { -ms-interpolation-mode: bicubic; }

img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
table { border-collapse: collapse !important; }
body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }


a[x-apple-data-detectors] {
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

@media screen and (max-width: 480px) {
    .mobile-hide {
        display: none !important;
    }
    .mobile-center {
        text-align: center !important;
    }
}
div[style*=\"margin: 16px 0;\"] { margin: 0 !important; }
</style>
<body style=\"margin: 0 !important; padding: 0 !important; background-color: #eeeeee;\" bgcolor=\"#eeeeee\">


<div style=\"display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family: Open Sans, Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;\">
Your registration at Hard Enduro Poiana Rusca 2024 has been successfully made! 
</div>

<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
    <tr>
        <td align=\"center\" style=\"background-color: #eeeeee;\" bgcolor=\"#eeeeee\">
        
        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:600px;\">
            <tr>
                <td align=\"center\" valign=\"top\" style=\"font-size:0; padding: 35px;\" bgcolor=\"#F44336\">
               
                <div style=\"display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;\">
                    <table align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:300px;\">
                        <tr>
                            <td align=\"left\" valign=\"top\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 36px; font-weight: 800; line-height: 48px;\" class=\"mobile-center\">
                                <h1 style=\"font-size: 26px; font-weight: 800; margin: 0; color: #ffffff;\">Hard Enduro Poiana Rusca 2024</h1>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div style=\"display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;\" class=\"mobile-hide\">
                    <table align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:300px;\">
                        <tr>
                            <td align=\"right\" valign=\"top\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; line-height: 48px;\">
                                <table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" align=\"right\">
                                    <tr>
                                        <td style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400;\">
                                            
                                        </td>
                                        <td style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 24px;\">
                                            <a href=\"#\" target=\"_blank\" style=\"color: #ffffff; text-decoration: none;\"><img src=\"https://img.icons8.com/color/48/000000/small-business.png\" width=\"27\" height=\"23\" style=\"display: block; border: 0px;\"/></a>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>
              
                </td>
            </tr>
            <tr>
                <td align=\"center\" style=\"padding: 35px 35px 20px 35px; background-color: #ffffff;\" bgcolor=\"#ffffff\">
                <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:600px;\">
                    <tr>
                        <td align=\"center\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;\">
                            <img src=\"https://img.icons8.com/carbon-copy/100/000000/checked-checkbox.png\" width=\"125\" height=\"120\" style=\"display: block; border: 0px;\" /><br>
                            <h2 style=\"font-size: 30px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;\">
                                Registration ".$aux.". <br>Thank You!
                            </h2>
                        </td>
                    </tr>
                    <tr>
                        <td align=\"left\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;\">
                            <p style=\"font-size: 16px; font-weight: 400; line-height: 24px; color: #777777;\">
                                Your information has been received by our team, your registration form is being completed.
                            </p>
                        </td>
                    </tr>
                </table>
                
                </td>
            </tr>
             
            <tr>
                <td align=\"center\" style=\" padding: 35px; background-color: #ff7361;\" bgcolor=\"#1b9ba3\">
                <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:600px;\">
                    <tr>
                        <td align=\"center\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;\">
                            <h2 style=\"font-size: 24px; font-weight: 800; line-height: 30px; color: #ffffff; margin: 0;\">
                                Reduce time spent on registration desk by completing online registration form.
                            </h2>
                        </td>
                    </tr>
                    <tr>
                        <td align=\"center\" style=\"padding: 25px 0 15px 0;\">
                            <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
                                <tr>
                                    <td align=\"center\" style=\"border-radius: 5px;\" bgcolor=\"#66b3b7\">
                                      <a href=\"www.enduropoianarusca.ro\" target=\"_blank\" style=\"font-size: 18px; font-family: Open Sans, Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; background-color: #F44336; padding: 15px 30px; border: 1px solid #F44336; display: block;\">Back to Website</a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                </td>
            </tr>
            <tr>
                <td align=\"center\" style=\"padding: 35px; background-color: #ffffff;\" bgcolor=\"#ffffff\">
                <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width:600px;\">
                    <tr>
                        
                    </tr>
                    <tr>
                        <td align=\"center\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px; padding: 5px 0 10px 0;\">
                            <p style=\"font-size: 14px; font-weight: 800; line-height: 18px; color: #333333;\">
                                Address: Casiana Guest House<br>
                                Hunedoara, Romania 337337
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td align=\"left\" style=\"font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 24px;\">
                            <p style=\"font-size: 14px; font-weight: 400; line-height: 20px; color: #777777;\">
                                We take your information as private so you don't have to worry about sharing them to anyone else.
                            </p>
                        </td>
                    </tr>
                </table>
                </td>
            </tr>
        </table>
        </td>
    </tr>
</table>
    
</body>
</html>
";

    $mail = $smtp->send($to, $headers, $body);

    header( "Location: succses.php" );

}
?>
