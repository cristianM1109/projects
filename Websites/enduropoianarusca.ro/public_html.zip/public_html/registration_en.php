<?php
include ('js/mail_handeler.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Registartion</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    <link rel="icon" href="images/logo_nav.png" type="image/x-icon">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	   <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Hard Enduro Poiana Rusca 2024</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item active"><a href="registration_en.php" class="nav-link">Registration</a></li>
	          <li class="nav-item"><a href="participants_en.php" class="nav-link">Participants</a></li>
	          <li class="nav-item"><a href="regulation_en.html" class="nav-link">Regulation</a></li>
	          <li class="nav-item"><a href="contact_en.html" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Registration</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Registration <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

   	
   

	
	<section class="ftco-section-parallax bg-secondary">
      <div class="parallax-img d-flex align-items-center">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
             
		<h2>Hard Enduro Poiana Rusca 2024 Online Registration</h2><br><br>	 
              <center>
		  <h2 style="color:red;font-size:21px">GPS is Mandatory !
		  The payment can only be done starting with 13 June at the race lobby(Casiana Guesthouse)</h2>
			  <br>
			  
    <div>
     <div class="panel panel-default">
       
          <div class="panel-body">
           <form action="<?=$_SERVER['PHP_SELF'] ?>" method="post" name="form">
               <label style="color: white;">Name</label>
               <input type="text" name="Nume" class="form-control" placeholder="Name" value="<?= $namee ?>">
               <h20><?=$nameErr ?></h20><br>
                      <label style="color: white;">Category</label>
                           <select name="sel" class="form-control" id="exampleSelect1">
                           <option></option>
                           <option>Pro</option>
                           <option>Expert</option>
						   <option>Shorty Expert</option>
                           <option>Hobby</option>
						   <option>Shorty Hobby</option>
                           <option>Girl</option>
                           <option>Veteran</option>
                        </select>
                <h20><?= $clsErr ?></h20><br>
                <label style="color: white;">Club/Sponsor</label>
        <input type="text" name="Club/Sponsor" class="form-control" placeholder="Club/Sponsor" value="<?= $class ?>">
                              <h20><?= $classErr ?></h20><br>
               <label style="color: white;">Email Address</label>
     <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="<?= $email ?>">
         <h20><?= $emailErr ?></h20><br><br>
             <label style="color: white;">Telephone</label>
                 <input type="text" name="Telefon" class="form-control" placeholder="No prefix needed" value="<?= $tel ?>">
                        <h20><?= $telErr ?></h20>
                             <br>
                                     <label style="color: white;">Age</label>
               <input type="text" name="Varsta" class="form-control" placeholder="Age" value="<?= $vrs ?>">
                               <h20><?= $vrsErr ?></h20>
                      
<br><br>
                                  <label style="color: white;">Country and City</label>
              <input type="text" name="Localitate" class="form-control" placeholder="Country and City" value="<?= $lcl ?>">
              <h20><?= $lclErr ?></h20>

                             <br>

                  <label style="color: white;">Additional information</label>
                <textarea class="form-control" name="Mesaj" id="exampleTextarea" rows="3" value="<?= $obs ?>"></textarea>
            <div>
                <br><br>

            <span class="error"><?= $cecErr ?></span>

              </div>
                             <br>
							 <center><input type="checkbox" name="rule" value="value_rule"> I have read and i agree with the race regulations.<br><br></center>

    <input type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Save and proceed to payment">
    <span class="succes"><?= $succses ?></span>
    </form>
           </div>
           </div>
    </div></center>
           
		   
            </div>
          </div>
        </div>
      </div>
    </section>
	
	
	<section class="ftco-gallery">
    	<div class="container-wrap">
    		<div class="row no-gutters">
					<div class="col-md-3 ftco-animate">
						<a href="images/image_1.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_1.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_2.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_2.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_3.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_3.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_4.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_4.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
        </div>
    	</div>
    </section>

    

      <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <img src="images/logo.png">
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="https://www.facebook.com/enduroHD/"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/hard_enduro_poiana_rusca/?hl=ro"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Looking for something else?</h2>
              <ul class="list-unstyled">
                <li><a href="registration_en.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Registration</a></li>
                <li><a href="participants_en.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Participants</a></li>
                <li><a href="regulation_en.html" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Regulation</a></li>
                <li><a href="contact_en.html" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Contact</a></li>
                
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Race Schedule</h2>
              <div class="opening-hours">
              	<h4>Opening Days:</h4>
              	<p class="pl-3">
					<span>Friday 13 June - Registration<br></span>
              		<span>Friday 14 June - Day 1 - Prologue<br></span>
              		<span>Sunday 15 June - Day 2<br></span>
					<span>Saturday 16 June - Day 3</span>
              	</p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Casiana Pension , Ciulpăz, DJ687J, 337337</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+40 742615550</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">HEPR@enduropoianarusca.ro</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
            <p>&copy;<script>document.write(new Date().getFullYear());</script> - HEPR - All rights reserved </a></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>