<?php
include ('js/mail_handeler.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Registartion</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    <link rel="icon" href="images/logo_nav.png" type="image/x-icon">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	   <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index_ro.html">Hard Enduro Poiana Rusca 2024</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	       <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index_ro.html" class="nav-link">Home</a></li>
	          <li class="nav-item active"><a href="registration_ro.php" class="nav-link">Inscriere</a></li>
	          <li class="nav-item"><a href="participants_ro.php" class="nav-link">Participanti</a></li>
	          <li class="nav-item"><a href="regulation_ro.html" class="nav-link">Regulament</a></li>
	          <li class="nav-item"><a href="contact_ro.html" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Inscriere</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index_ro.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Inscriere <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

   	
   

	
	<section class="ftco-section-parallax bg-secondary">
      <div class="parallax-img d-flex align-items-center">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
             
		<h2>Hard Enduro Poiana Rusca 2024 Inscriere Online</h2><br>
              <center>
				  <h2 style="color:red;font-size:21px">GPS-ul este obligatoriu !
Plata se va face doar cash incepand cu data de 13 Iunie la secretariatul concursului.(Pensiunea Casiana)</h2>
    <div>
     <div class="panel panel-default">
       
          <div class="panel-body">
           <form action="<?=$_SERVER['PHP_SELF'] ?>" method="post" name="form">
               <label style="color: white;">Nume</label>
               <input type="text" name="Nume" class="form-control" placeholder="Nume" value="<?= $namee ?>">
               <span class="error"><?=$nameErr ?></span><br>
                      <label style="color: white;">Categorie</label>
                           <select name="sel" class="form-control" id="exampleSelect1">
                           <option></option>
                           <option>Pro</option>
                           <option>Expert</option>
						   <option>Shorty Expert</option>
                           <option>Hobby</option>
						   <option>Shorty Hobby</option>
                           <option>Girl</option>
                           <option>Veteran</option>
                        </select>
                <span class="error"><?= $clsErr ?></span><br>
                <label style="color: white;">Club/Sponsor</label>
        <input type="text" name="Club/Sponsor" class="form-control" placeholder="Club/Sponsor" value="<?= $class ?>">
                              <span class="error"><?= $classErr ?></span><br>
               <label style="color: white;">Email</label>
     <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Adresa email" value="<?= $email ?>">
      <small id="emailHelp" class="form-text text-muted" style="color: white;">We'll never share your email with anyone else.</small><br>
         <span class="error"><?= $emailErr ?></span><br><br>
             <label style="color: white;">Telefon</label>
                 <input type="text" name="Telefon" class="form-control" placeholder="Telefon" value="<?= $tel ?>">
                        <span class="error"><?= $telErr ?></span>
                             <br>
                                     <label style="color: white;">Varsta</label>
               <input type="text" name="Varsta" class="form-control" placeholder="Varsta" value="<?= $vrs ?>">
                               <span class="error"><?= $vrsErr ?></span>
                       <br><br>
               <label style="color: white;">Tip motocicleta</label>
               <br>
<label class="radio-inline" style="color: white;">
      <input type="radio" name="optradio1" >2 Stroke
    </label>
    <label class="radio-inline" style="color: white;">
      <input type="radio" name="optradio2" >4 Stroke
    </label>
<br>
         <span class="error"><?= $rdiErr ?></span>
<br><br>
                                  <label style="color: white;">Oras</label>
              <input type="text" name="Localitate" class="form-control" placeholder="Oras" value="<?= $lcl ?>">
              <span class="error"><?= $lclErr ?></span>

                             <br>

                  <label style="color: white;">Informatii suplimentare</label>
                <textarea class="form-control" name="Mesaj" id="exampleTextarea" rows="3" value="<?= $obs ?>"></textarea>
            <div>
                <br><br>

            <span class="error"><?= $cecErr ?></span>

              </div>
                             <br>

    <input type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Trimite">
    <span class="succes"><?= $succses ?></span>
    </form>
           </div>
           </div>
    </div></center>
           
		   
            </div>
          </div>
        </div>
      </div>
    </section>
	
	
	<section class="ftco-gallery">
    	<div class="container-wrap">
    		<div class="row no-gutters">
					<div class="col-md-3 ftco-animate">
						<a href="images/image_1.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_1.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_2.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_2.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_3.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_3.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/image_4.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/image_4.jpg);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
        </div>
    	</div>
    </section>

    

     <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <img src="images/logo.png">
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="https://www.facebook.com/enduroHD/"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/hard_enduro_poiana_rusca/?hl=ro"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Pagini alternantive</h2>
              <ul class="list-unstyled">
			    <li><a href="index.html" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Aceste site are o varianta in <h9>English</h9></a></li>
                <li><a href="registration_ro.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Inscriere</a></li>
                <li><a href="participants_ro.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Participanti</a></li>
                <li><a href="regulation_ro.html" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Regulament</a></li>
                <li><a href="contact_ro.html" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Contact</a></li>
                
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Program de Concurs</h2>
              <div class="opening-hours">
              	<p class="pl-3">
              		<span>Vineri 14 Iunie - Prolog<br></span>
              		<span>Sambata 15 Iunie - 90 de km traseu<br></span>
					<span>Duminica 16 Iunie - 100 de km traseu</span>
              	</p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Contact Info</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Pensiunea Casiana , Ciulpăz, DJ687J, 337337</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+40 742615550</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">HEPR@enduropoianarusca.ro</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
            <p>&copy;<script>document.write(new Date().getFullYear());</script> - HEPR - Toate drepturile rezervate </a></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>