<?php


$conect_err=0;
$dtbase_err=0;
$nofind_err=0;
$page_err=0;
$photo_err=0;

$conn = mysqli_connect("188.241.222.184","autoclau_auto","corvin1921","autoclau_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	$conect_err=1;
}
error_reporting(0);

$id=$_GET['id'];


$sql = "SELECT page FROM anunt WHERE id='$id'";
$result = $conn->query($sql);

if($result){
	//sa gasit linia din tabel cu id=id
}
else{
	$nofind_err=1;
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $page=$row["page"];
}

if(unlink($page)){
	//sa sters
}
else{
	$page_err=1;
}

$sql = "SELECT path FROM images WHERE id=$id";
$result = $conn->query($sql);
 if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()) {				
					if(unlink("upload/".$row["path"])){
						//sa sters poza;
					}
					else{
						$photo_err=1;
					}
				}
 }
 $sql = "SELECT path FROM img_idx WHERE id=$id";
$result = $conn->query($sql);
 if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()) {				
					if(unlink("idx_pho/".$row["path"])){
						//sa sters e ok
					}
					else{
						$photo_err=1;
					}
					if(unlink("title/".$row["path"])){
						//sa sters e ok
					}
					else{
						$photo_err=1;
					}
				}
 }
 $sql = "SELECT path FROM tumb WHERE id=$id";
$result = $conn->query($sql);
 if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()) {				
					if(unlink("tumb/".$row["path"])){
						//sa sters e ok
					}
					else{
						$photo_err=1;
					}
				}
 }


$sql = "DELETE FROM anunt WHERE id='$id'";
$result = $conn->query($sql);

if($result){
      //sa sters e ok
}
else{
	$dtbase_err=1;
}

$sql = "DELETE FROM images WHERE id='$id'";
$result = $conn->query($sql);

if($result){
	 //sa sters e ok
}
else{
	$dtbase_err=1;
}

$sql = "DELETE FROM img_idx WHERE id='$id'";
$result = $conn->query($sql);

if($result){
	 //sa sters e ok
}
else{
	$dtbase_err=1;
}
$sql = "DELETE FROM tumb WHERE id='$id'";
$result = $conn->query($sql);

if($result){
	 //sa sters e ok
}
else{
	$dtbase_err=1;
}

if($conect_err || $dtbase_err || $nofind_err || $page_err || $photo_err){
if($conect_err){
	$ms1="Nu se poate realiza conexiunea la baza de date!<br>";
    }
if($dtbase_err){
	$ms2="Nu sa putut sterge informatiile din baza de date!<br>";
    }
if($nofind_err){
	$ms3="Nu sa gasit anuntul selectat!<br>";
    }
if($page_err){
	$ms4="Nu sa gasit pagina aferenta anuntului pe server!<br>";
    }
	if($photo_err){
	$ms5="Nu s-au gasit pozele selectat pe server!<br>";
    }
 header("location:error_del.php?ms1=$ms1&ms2=$ms2&ms3=$ms3&ms4=$ms4&ms5=$ms5");
}else{
 header("location:success_del.html");
}


?>