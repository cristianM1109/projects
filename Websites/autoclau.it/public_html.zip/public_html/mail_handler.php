<?php
require_once("Mail.php");

$emaill  = "cristi_12hd@yahoo.com";
$replyto = "contact@toyvehicules.com";
$to      = "< " . $emaill . " > ";
$subject = "Client message";
$mailer  = 'PHP/' . phpversion();




$namee   = $email = $subj = $msg = "";
$succses = "";

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
    if (empty($_POST["Name"])) {
        
    } else {
        $namee = test_input($_POST["Name"]);
    }
	
	
    
    if (empty($_POST["email"])) {
        
    } else {
        $email = test_input($_POST["email"]);
        if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $email)) {
            $emailErr = "EMAIL INVALID FORMAT!<br><br>";
        }
    }
    
	
	
    if (empty($_POST["subj"])) {
       
    } else {
        $subj = test_input($_POST["subj"]);
    }
	
	
	
	if (empty($_POST["message"])) {
        
    } else {
        $msg = test_input($_POST["message"]);
    }
    
	
	


  
        $body = "";
        unset($_POST["submit"]);
        
        $from = "Toyvehicules <contact@toyvehicules.com>";
        
        $body .= "Nume: " . $namee . "<br>";
        $body .= "Email: " . $email . "<br>";
        $body .= "Subject: " . $subj . "<br>";
        $body .= "Mesaj : " . $msg . "<br>";
        
		$subject = $subj;
        $aux     = $namee;
        $aux2    = $email;
        $namee   = $category = $email = $club = $msg = $lcl = $tshirt = $subj = $engine = $obs = "";
        $succses = "";
        
        
        $host     = "mail.toyvehicules.com";
        $username = "contact@toyvehicules.com";
        $password = "Powervalve";
        
       
        
        $headers = array(
            'From' => $from,
            'Reply-To' => $replyto,
            'Subject' => $subject,
            'MIME-Version' => "1.0",
            'To' => $to,
            'Content-type' => 'text/html; charset=iso-8859-1'
        );
        
        
        $smtp = Mail::factory('smtp', array(
            'host' => $host,
            'port' => '26',
            'auth' => true,
            'username' => $username,
            'password' => $password
        ));
        
        
        $mail = $smtp->send($to, $headers, $body);
        
       
        
        $to      = "< " . $aux2 . " > ";
        $replyto = "contact@toyvehicules.com";
        
        $headers = array(
            'From' => $from,
            'Reply-To' => $replyto,
            'Subject' => $subject,
            'MIME-Version' => "1.0",
            'To' => $to,
            'Content-type' => 'text/html; charset=iso-8859-1'
        );
        
        $body = "Multumim pentru interesul acordat, am primit informatiile dumneavoastra. Vom reveni cu un raspuns in cel mai scurt timp posibil!<br><br> <br> Cu respect ,echipa Toyvehicules.   <br><br><br><br><br> Thank you for your interest , we've received your information.We will come back with an answer as soon as possible!<br><br><br> Respectfully,Toyvehicules team.";
        
        $mail = $smtp->send($to, $headers, $body);
        
        
    }
?>
