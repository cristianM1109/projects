<?php 
require_once("conection.php");
$connect;

$var="1";

$id=$_GET["id"];

session_start();

if(isset($_SESSION['user'])){

$var="";

}

$sql = "SELECT titlu FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if ($result->num_rows > 0){
	$row = $result->fetch_assoc();
	
$titlu=$row['titlu'];
}

$sql1 = "SELECT path FROM images WHERE id='$id' ORDER BY path ASC";
$sql2 = "SELECT path FROM tumb WHERE id='$id' ORDER BY path ASC";
$photos="";
		$result1 = mysqli_query($connect,$sql1);
		$result2 = mysqli_query($connect,$sql2);
		   if (($result1->num_rows > 0) && ($result2->num_rows > 0)){
			    while(($row1 = $result1->fetch_assoc()) && ($row2 = $result2->fetch_assoc())) {
				
				    $path=$row1["path"];
					$path2=$row2["path"];
                    					
					$photos.= "<li class=\"col-xs-6 col-sm-4 col-md-2 col-lg-2\" data-responsive='upload/".$path."' data-src='upload/".$path."' data-sub-html=''>".
                              "<a href=''>".
                              "<img class=\"img-responsive\" src='tumb/".$path2."'>".
                              "</a>".
                              "</li>";		
		   }
		   }
		   
		   
$sql = "SELECT page FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sa gasit linia din tabel cu id=id
}
else{
	$nofind_err=1;
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $page_addr=$row["page"];
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo $titlu; ?></title>
		<link rel='icon' href='assets/images/logoo.ico'>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/lightgallery/1.3.9/css/lightgallery.min.css" rel="stylesheet">
        <style>
		body{
			background-color:#152836
			}
		h2{
			color:#fff;
			margin-bottom:40px;
			text-align:center;
			font-weight:100;
			}
			
		#buton1{

        display:none;
		}	
       
	   		
			
			</style>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		     <link rel='stylesheet' href='style.css'>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    </head>
    <body class="home">
        <div class="container" style="margin-top:40px;">
            <h2><?php echo $titlu; ?></h2>
            <div class="demo-gallery">
                <ul id="lightgallery" class="list-unstyled row">
                   <?php echo $photos; ?>
                </ul>
            </div>
			<center><a href="<?php echo $page_addr;?>" class="btn btn-info" role="button"><i class="fa fa-angle-double-left"></i>  Go Back</a></center><br>
			<center><a href="galery_menu.php?id=<?php echo $id; ?>&err=""" class="btn btn-warning" id="buton<?php echo $var; ?>" role="button"><i class="fa fa-bars"></i>  Editeaza</a></center><br>
        </div>
		<script src="galery.js"></script>
        <script>
            $(document).ready(function(){
                $('#lightgallery').lightGallery(); 
            });
        </script>
    </body>    
</html>