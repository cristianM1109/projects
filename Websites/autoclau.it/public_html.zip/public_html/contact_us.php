<?php
require_once("state.php");
 ?>

<!DOCTYPE html>
<!--[if IE 9]>
<html class="ie ie9" lang="en-US">
<![endif]-->
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <title>AutoClau</title>
	 
	 <link rel="icon" href="assets/images/logoo.ico">
	 <link rel="shortcut icon" href="assets/images/logoo.ico">


	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- Slider Pro Css -->
	<link rel="stylesheet" href="assets/css/sliderPro.css">
	<!-- Owl Carousel Css -->
	<link rel="stylesheet" href="assets/css/owl-carousel.css">
	<!-- Flat Icons Css -->
	<link rel="stylesheet" href="assets/css/flaticon.css">
	<!-- Animated Css -->
	<link rel="stylesheet" href="assets/css/animated.css">
	<!-- Footer -->
	<link rel="stylesheet" href="assets/css/footer.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
   
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	 <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	
	<style>
	h10 {
  display: block;
  font-size: 2em;
  margin-top: 0.67em;
  margin-bottom: 0.67em;
  margin-left: 0;
  margin-right: 0;
  font-weight: bold;
  font-family: Arvo;
}
      #button {
            background-color: #88FF6A;
            border: none;
            text-decoration: none;
            color: white;
			width: 50%;
            padding:20px;
			line-height: 0px;
			height: 0px;
            margin: 20px 20px;
            cursor: pointer;
	  }
	  #button:hover {
  background-color: #cc7a00;
}

.contact .php-email-form .loading {
  display: none;
  background: #fff;
  text-align: center;
  padding: 15px;
}
.contact .php-email-form .loading:before {
  content: "";
  display: inline-block;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  margin: 0 10px -6px 0;
  border: 3px solid #18d26e;
  border-top-color: #eee;
  -webkit-animation: animate-loading 1s linear infinite;
  animation: animate-loading 1s linear infinite;
}
.contact .php-email-form input, .contact .php-email-form textarea {
  border-radius: 0;
  box-shadow: none;
  font-size: 14px;
}
.contact .php-email-form input {
  height: 44px;
}
.contact .php-email-form textarea {
  padding: 10px 12px;
}
.contact .php-email-form button[type=submit] {
  background: #7cc576;
  border: 0;
  padding: 10px 24px;
  color: #fff;
  transition: 0.4s;
  border-radius: 4px;
}
.contact .php-email-form button[type=submit]:hover {
  background: #61b959;
}
@-webkit-keyframes animate-loading {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes animate-loading {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

input[type=submit] {
    padding: 5px 15px;
    background: #7cc576;
    border: 0 none;
    cursor: pointer;
    -webkit-border-radius: 5px;
    border-radius: 5px;
}

.contact .php-email-form .error-message {
    display: none;
    color: #fff;
    background: #ed3c0d;
    text-align: left;
    padding: 15px;
    font-weight: 600;
}

.contact .php-email-form .sent-message {
    display: none;
    color: #fff;
    background: #18d26e;
    text-align: center;
    padding: 15px;
    font-weight: 600;
}

.contact .php-email-form {
    width: 100%;
    background: #fff;
    padding: 20px;
    border-radius: 5px;
}

.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	left:10px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
}

	</style>


	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

</head>
<body>

	
	
	<div class="preloader">
        <div class="preloader-bounce">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
	
	<div id="search">
	    <button type="button" class="close">×</button>
	    <form>
	        <input type="search" value="" placeholder="type keyword(s) here" />
	       
	    </form>
	</div>
	
	<header class="site-header wow fadeIn" data-wow-duration="1s">
		<div id="main-header" class="main-header">
			<div class="container clearfix">
				<div class="logo">
					<a href="index.php"></a>
				</div>
				<div id='cssmenu'>
					<ul>
					   	<li><a href='index.php'>Homepage</a></li>
					   	<li class='active'><a href='car_listing_sidebar.php'>Elenco Delle Auto</a>
					   	</li>
					   <li><a href='contact_us.php'>Contatto</a></li>
					   <li><a href='<?php echo $redirect; ?>'><?php echo $state; ?></a>
					  
					</ul>
				</div>
			</div>
		</div>
	</header>


	<div class="page-heading wow fadeIn" data-wow-duration="0.5s">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="heading-content-bg wow fadeIn" data-wow-delay="0.75s" data-wow-duration="1s">
						<div class="row">
							<div class="heading-content col-md-12">
								<p><a href="index.php">Homepage</a> / <em> Contatto</em></p>
								<h2> <em>Contatto</em></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="contact-us wow fadeIn" data-wow-delay="0.5s" data-wow-duration="1s">
		<div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=43.84340902286407, 10.481278110516113+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://www.maps.ie/route-planner.htm"></a></div>
	</div>
<!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container">

        <div class="section-title">
         <div class="sep-section-heading">
								<h2><em>INVIACI UN MESSAGGIO</em></h2>
							</div>
          </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="info d-flex flex-column justify-content-center" data-aos="fade-right">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Posizione:</h4>
                <p>Lucca, Via Vittorio Bachelet 202, 55100, Italia</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>macchine@autoclau.it</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Telefono:</h4>
                <p>+39 349 839 5861</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0">

            <form action="forms/contact.php" method="post" role="form" class="php-email-form" data-aos="fade-left">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Il tuo nome..." required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="La tua email..." required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Materia..." required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Messaggio..." required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Caricamento in corso</div>
                <div class="error-message">Si è verificato un errore! Per favore riprova più tardi!</div>
                <div class="sent-message">Il tuo messaggio è stato inviato!</div>
              </div>
              <div class="text-center"><input type="submit" id="btnSubmit" value="Spedire" /></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->
	


	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-center text-md-center">
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Menù</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="index.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="car_listing_sidebar.php"><i class="fa fa-angle-double-right"></i>Elenco Delle Auto</a></li>
						<li><a href="contact_us.php"><i class="fa fa-angle-double-right"></i>Contatto</a></li>
						<li><a href='<?php echo $redirect; ?>'><i class="fa fa-angle-double-right"></i><?php echo $state; ?></a>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<br><br><br>
					 <div class="logoo">
						<img src="assets/images/logoo_f.png"></center>
						
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-4 col-md-4">
				<br><br><br>
					<h5>Informazioni di contatto</h5>
					<ul class="list-unstyled quick-links">
						<li><h2><i class="fa fa-map-marker" aria-hidden="true">  Lucca, Via Vittorio Bachelet 202, 55100, Italia</i></h2></li>
						
						<li><a href='tel:+39 349 839 5861'><i class="fa fa fa-phone"></i>+39 349 839 5861</a></li>
						<br>
						<li><a href="mailto:macchine@autoclau.it"><i class="fa fa-envelope"></i>macchine@autoclau.it</a></li>
						<br>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="">AutoClau</a></u> è una società a responsabilità limitata registrata fondata nel 2022.</p>
					<p class="h6">©<a class="text-green ml-2" href="#" target="_blank">Tutti i diritti riservati.</a></p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
	
<a href="https://api.whatsapp.com/send?phone=+393498395861&text=Ciao%21%20Voglio%20comprare%20una%20macchina%20!" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>


	<script src="assets/js/jquery-1.11.0.min.js"></script>

	<!-- Slider Pro Js -->
	<script src="assets/js/sliderpro.min.js"></script>

	<!-- Slick Slider Js -->
	<script src="assets/js/slick.js"></script>

	<!-- Owl Carousel Js -->
    <script src="assets/js/owl.carousel.min.js"></script>

	<!-- Boostrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Boostrap Js -->
    <script src="assets/js/wow.animation.js"></script>
	
	<script src="assets/vendor/php-email-form/validate.js"></script>

	<!-- Custom Js -->
    <script src="assets/js/custom.js"></script>

    <!-- Google Map -->
    <script src="https://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="assets/js/jquery.gmap3.min.js"></script>

	
    

</body>
</html>