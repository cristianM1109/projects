<?php 

if(!($connect=mysqli_connect("188.241.222.184","autoclau_auto","corvin1921","autoclau_resource"))){
	 die("Connection failed");
}

?>