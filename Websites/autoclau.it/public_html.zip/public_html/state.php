<?php

session_start();

$redirect="login.php";
$state="Accesso";
if(isset($_SESSION['user'])){
	$state="Impostazioni";
	$redirect="logged.php";
}



 ?>