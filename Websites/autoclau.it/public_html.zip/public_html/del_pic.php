<?php 
$name=$_GET["name"];
$id=$_GET["id"];
$err="";

$conn = mysqli_connect("188.241.222.184","autoclau_auto","corvin1921","autoclau_resource") or die("Connection failed");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	$conect_err=1;
}
error_reporting(0);

$sql = "SELECT path FROM img_idx WHERE path='$name'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
	$err="Nu poti sterge poza de profil a anuntului.Alege o alta poza de profil dupa care reincearca stergerea!";
	header("Location:galery_menu.php?id=$id&err=$err");
	die();
}

if(unlink("upload/".$name)){
						//sa sters e ok
					}
					else{
						$photo_err=1;
					}

					
if(unlink("tumb/".$name)){
						//sa sters e ok
					}
					else{
						$photo_err=1;
					}
					
					
$sql = "DELETE FROM images WHERE path='$name'";
$result = $conn->query($sql);

if($result){
	 //sa sters e ok
}
else{
	$dtbase_err=1;
}


$sql = "DELETE FROM tumb WHERE path='$name'";
$result = $conn->query($sql);

if($result){
	 //sa sters e ok
}
else{
	$dtbase_err=1;
}

header("Location:galery_menu.php?id=$id&err=$err");

?>