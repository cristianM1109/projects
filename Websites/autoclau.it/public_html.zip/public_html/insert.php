<?php
ob_start();


$titlu="";
$pret="";
$af="";
$km="";
$comb="";
$link="";
$trans="";
$cm="";
$desc="";
$id="";
$mysqli="";
$stop="";
$buton_show="";
$video_value=0;

function compress_image($source_url, $destination_url, $quality) {
        $info = getimagesize($source_url);
        if ($info['mime'] == 'image/jpeg')
            $image = imagecreatefromjpeg($source_url);
        elseif ($info['mime'] == 'image/gif')
            $image = imagecreatefromgif($source_url);
        elseif ($info['mime'] == 'image/png')
            $image = imagecreatefrompng($source_url);
        imagejpeg($image, $destination_url, $quality);
        return $destination_url; 
    } 

function seoUrl($string) {
    //Lower case everything
    $string = strtolower($string);
    //Make alphanumeric (removes all other characters)
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string = preg_replace("/[\s-]+/", " ", $string);
    //Convert whitespaces and underscore to dash
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
}

$words=seoUrl($titlu);
$name=$words.uniqid('',true).".php";

 

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
session_start();
require_once("conection.php");
require_once("smart_resize_image.function.php");
	
$ok1 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Titlu']);
$ok2 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Pret']);
$ok3 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['af']);
$ok4 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Kilometri']);
$ok5 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Combustibil']);
$ok6 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Transmisie']);
$ok7 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Cm3']);
$ok8 = preg_match('/^[a-zA-Z0-9 \r\n\'\,.\-]+$/i', $_POST['Descriere']);
$ok9 = preg_match('/^[a-zA-Z0-9 .\-]+$/i', $_POST['Disponibilitate']);

$ok_all = 0;

	
if ($ok1 and $ok2 and $ok3 and $ok4 and $ok5 and $ok6 and $ok7 and $ok8 and $ok9){
	$ok_all = 1;
}

if ($ok_all){
$titlu=addslashes($_POST['Titlu']);
$pret=addslashes($_POST['Pret']);
$af=addslashes($_POST['af']);
$km=addslashes($_POST['Kilometri']);
$comb=addslashes($_POST['Combustibil']);
$trans=addslashes($_POST['Transmisie']);
$cm=addslashes($_POST['Cm3']);
$desc=addslashes($_POST['Descriere']);
$statu=addslashes($_POST['Disponibilitate']);




$v1=0;
$v2=0;
$v3=0;
$v4=0;
$v5=0;
$v6=0;
$ms1="";
$ms2="";
$ms3="";
$ms4="";
$ms5="";
$ms6="";

$link="0";
$video_value="0";

	
		$sql = "INSERT INTO anunt (titlu, pret, af, km, combustibil, transmisie, cm, descriere,page,status,link,video_show) VALUES ('$titlu', '$pret', '$af', '$km', '$comb', '$trans', '$cm', '$desc','$name','$statu','$link','$video_value')";
if(mysqli_query($connect, $sql)){
    //ok sa executat
} else{
	$v1=1;
}	

 
 // Count total files
 $countfiles = count($_FILES['file']['name']);


if ($result = mysqli_query($connect, "SELECT id FROM anunt WHERE id=(SELECT max(id) FROM anunt)")) {
  //sa gasit ultima linie
}
if ($result->num_rows > 0){
       $row = $result->fetch_assoc();
	   $id=$row["id"];
}
else{
	$v1=1;
}

 // Looping all files
 for($i=0;$i<$countfiles;$i++){
  $fileName = $_FILES['file']['name'][$i];
  $fileTmpName = $_FILES['file']['tmp_name'][$i];
  $fileSize = $_FILES['file']['size'][$i];
  $fileError = $_FILES['file']['error'][$i];
  $fileType = $_FILES['file']['type'][$i];
  
  
  
  $fileExt = explode('.',$fileName);
  $fileActualExt= strtolower(end($fileExt));
  
    $allowed = array('jpg','jpeg','png');
  
  
    if(in_array($fileActualExt, $allowed)){
		if($fileError == 0){
			if($fileSize < 10000000){
	        	$fileNameNew=uniqid('',true).".".$fileActualExt;
		        $sql = "INSERT INTO images (path, id) VALUES ('$fileNameNew', '$id')";
 
    if(mysqli_query($connect, $sql)){
        
    } else{
           echo "ERROR: Could not able to execute $sql. " . mysqli_error($connect);
		   $v2=1;
    }
	
	         	
		        move_uploaded_file($fileTmpName,"upload/".$fileNameNew);
				
                smart_resize_image("upload/".$fileNameNew , null, 1920 , 1080 , false , "upload/".$fileNameNew , false , false ,40 );
				smart_resize_image("upload/".$fileNameNew , null, 348 , 235 , false , "tumb/".$fileNameNew , false , false ,50 );
				 
				 $sql1 = "INSERT INTO tumb (path, id) VALUES ('$fileNameNew', '$id')";
				if( mysqli_query($connect, $sql1)){
                
				}
				else{$v3=1;}
				
	            if($i==0){
	            smart_resize_image("upload/".$fileNameNew , null, 370 , 345 , false , "title/".$fileNameNew , false , false ,80 );
				smart_resize_image("upload/".$fileNameNew , null, 370 , 260 , false , "idx_pho/".$fileNameNew , false , false ,80 );
				 $sql = "INSERT INTO img_idx (path, id) VALUES ('$fileNameNew', '$id')";
				
				 
				 if(mysqli_query($connect, $sql)){
          // baza de date actualzi ok
    } else{
		$v3=1;
		$ms3="ERROR: Could not able to execute $sql or $sql1. " . mysqli_error($connect);
    }
  }				    
		}
		else{
			$v4=1;
			$ms4="Fisierul:".$fileName." este prea mare!<br>";
		}
	}
	else{
	   $v5=1;
	   $msg5="Sa produs o eroare la incarcarea fisierului:".$fileName."!<br>";
	}
	}
	else{
		$v6=1;
	}
 }
 


if(!($v1 || $v2 || $v3 || $v4 || $v5 || $v6)){

$sql1 = "SELECT path FROM images WHERE id='$id' ORDER BY id ASC";
$photos="";
$photos2="";
		$result1 = mysqli_query($connect,$sql1);
		   if ($result1->num_rows > 0){
			    while($row1 = $result1->fetch_assoc()) {
				
				    $path=$row1["path"];
                    					
					$photos2.="<img class='sp-thumbnail' src='upload/".$path."' alt='' />";
					$photos.="<div class='sp-slide'><a href='galery.php?id=<?php echo \$id;?>'><img class='sp-image' src='upload/".$path."' alt='' /></a>"."</div>";		
		   }
		   }
		                                                   
	
$strOut="<?php require_once(\"state.php\"); require_once(\"conection.php\");". 
          "\$id=".$id.";".
		   "\$sql1 = \"SELECT path FROM images WHERE id='\$id' ORDER BY id ASC\";".
          "\$photos=\"\";".
           "\$photos2=\"\";".
		   "\$result1 = mysqli_query(\$connect,\$sql1);".
		   "if (\$result1->num_rows > 0){".
			    "while(\$row1 = \$result1->fetch_assoc()) {".
				
				    "\$path=\$row1[\"path\"];".
                    					
					"\$photos2.=\"<img class='sp-thumbnail' src='upload/\".\$path.\"' alt='' />\";".
					"\$photos.=\"<div class='sp-slide'><a href='galery.php?id=$id;'><img class='sp-image' src='upload/\".\$path.\"' alt='' /></a>\".\"</div>\";".		
		   "}".
		   "}".
          "\$sql = \"SELECT titlu, pret, af ,km ,combustibil ,transmisie ,cm ,descriere,link,video_show,id FROM anunt where id=\$id ORDER BY id ASC\";".
		  "\$result = \$connect->query(\$sql);".
		  "\$path=\"\";".
		  "if (\$result->num_rows > 0) {".
          "\$row = \$result->fetch_assoc();". 	
		"\$titlu=\$row[\"titlu\"];".
		"\$pret=\$row[\"pret\"];".
		"\$af=\$row[\"af\"];".
		"\$ok=\$row[\"video_show\"];".
		"\$link=\$row[\"link\"];".
		"\$comb=\$row[\"combustibil\"];".
		"\$km=\$row[\"km\"];".
		"\$trans=\$row[\"transmisie\"];".
		"\$cm=\$row[\"cm\"];".
		"\$desc1=\$row[\"descriere\"];".
		"\$desc=nl2br(\$desc1);".
		  "}".
		  "?>".
		"<!DOCTYPE html>".
    "<html lang='en-US'>".
       "<head>".
    "<meta charset='UTF-8'>".
    "<meta name='description' content=''>".
    "<meta name='keywords' content='HTML,CSS,XML,JavaScript'>".
    "<meta name='viewport' content='width=device-width, initial-scale=1.0'>".
    "<title>AutoClau</title>".
	"<link rel='icon' href='assets/images/logoo.ico'>".
	"<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>".
    "<link rel='stylesheet' type='text/css' href='assets/css/lightbox.min.css'>".
	"<link rel='stylesheet' href='assets/css/bootstrap.css'>".
	"<link rel='stylesheet' href='assets/css/font-awesome.min.css'>".
	"<link rel='stylesheet' href='assets/css/main.css'>".
	"<!-- Slider Pro Css -->".
	"<link rel='stylesheet' href='assets/css/sliderPro.css'>".
	"<!-- Owl Carousel Css -->".
	"<link rel='stylesheet' href='assets/css/owl-carousel.css'>".
	"<!-- Flat Icons Css -->".
	"<link rel='stylesheet' href='assets/css/flaticon.css'>".
	"<!-- Animated Css -->".
	"<link rel='stylesheet' href='assets/css/animated.css'>".
	"<!-- Footer -->".
	"<link rel=\"stylesheet\" href=\"assets/css/footer.css\">".
	
     "<link rel=\"stylesheet\" href=\"assets/css/galery_style.css\">".
     "<link rel=\"stylesheet\" href=\"venobox/venobox.css\" type=\"text/css\" media=\"screen\" />".
	 
	 " <style>".
	"#button {".
  "background-color: red;".
  "box-shadow: 0 5px 0 darkred;".
  "color: white;".
  "padding: 0.5em 0.5em;".
 " position: relative;".
  "text-decoration: none;".
"}".
"#button:hover {".
 " background-color: #ce0606;".
"}".

"#button:active {".
" box-shadow: none;".
 " top: 5px;".
"}".

".float{".
	"position:fixed;".
	"width:60px;".
	"height:60px;".
	"bottom:20px;".
	"left:10px;".
	"background-color:#25d366;".
	"color:#FFF;".
	"border-radius:50px;".
	"text-align:center;".
  "font-size:30px;".
	"box-shadow: 2px 2px 3px #999;".
 "z-index:100;".
"}".

".my-float{".
	"margin-top:16px;".
"}".

	"</style>".
	
"</head>".
"<body>".
	"<div id='search'>".
	    "<button type='button' class='close'>×</button>".
	    "<form>".
	        "<input type='search' value='' placeholder='type keyword(s) here' />".
	    "</form>".
	"</div>".
	"<header class='site-header wow fadeIn' data-wow-duration='1s'>".
		"<div id='main-header' class='main-header'>".
			"<div class='container clearfix'>".
				"<div class='logo'>".
					"<a href='index.php'></a>".
				"</div>".
				"<div id='cssmenu'>".
					"<ul>".
					   	"<li><a href='index.php'>Homepage</a></li>".
					   	"<li class='active'><a href='car_listing_sidebar.php'>Elenco Delle Auto</a>".
					   	"</li>".
					    "<li><a href='contact_us.php'>Contatto</a></li>".
					   "<li><a href='<?php echo \$redirect; ?>'><?php echo \$state; ?></a>".
					"</ul>".
				"</div>".
			"</div>".
		"</div>".
	"</header>".
	"<div class='page-heading wow fadeIn' data-wow-duration='0.5s'>".
		"<div class='container'>".
			"<div class='row'>".
				"<div class='col-md-12'>".
					"<div class='heading-content-bg wow fadeIn' data-wow-delay='0.75s' data-wow-duration='1s'>".
						"<div class='row'>".
							"<div class='heading-content col-md-12'>".
								"<p><a href='index.php'>Homepage</a> / <em> Automobili</em> / <em> Dettagli auto</em></p>".
								"<h2>Macchina <em>Particolari</em></h2>".
							"</div>".
						"</div>".
					"</div>".
				"</div>".
			"</div>".
		"</div>".
	"</div>".
	"<div class='recent-car single-car wow fadeIn' data-wow-delay='0.5s' data-wow-duration='1s'>".
		"<div class='container'>".
			"<div class='recent-car-content'>".
				"<div class='row'>".
					"<div class='col-md-6'>".
						"<div id='single-car' class='slider-pro'>".
							"<div class='sp-slides'>".
								"<?php echo \$photos; ?>".
							"</div>".
							"<div class='sp-thumbnails'>".
								"<?php echo \$photos2; ?>".
							"</div>".
					    "</div>".
					"</div>".
					"<div class='col-md-6'>".
						"<div class='car-details'>".
							"<h4>"."<?php echo \$titlu; ?>"."</h4>".
							"<span>€"."<?php echo \$pret; ?>"."</span>".
							"<div class='container'>".
								"<div class='row'>".
									"<ul class='car-info col-md-6'>".
										"<li><i class='flaticon flaticon-calendar'></i><p>"."<?php echo \$af; ?>"."</p></li>".
										"<li><i class='flaticon flaticon-road'></i><p>"."<?php echo \$km; ?>"."km</p></li>".
										"<li><i class='flaticon flaticon-fuel'></i><p>"."<?php echo \$comb; ?>"."</p></li>".
									"</ul>".
									"<ul class='car-info col-md-6'>".
										"<li><i class='flaticon flaticon-shift'></i><p>"."<?php echo \$trans; ?>"."</p></li>".
										"<li><i class='flaticon flaticon-motor'></i><p>"."<?php echo \$cm; ?>"."</p></li>".
									"</ul>".
								"</div>".
							"</div>".
							"<div id=\"hide\">".
						 "<h10 style=\"color: #b48608; font-family: 'Droid serif', serif; font-size: 18px; font-weight: 700;\">Watch restauration of this car on</h10><br>".
                           "<br><input style=\"display:none;\" value='<?php echo \$ok; ?>' id='show_hide'><a href='<?php echo \$link; ?>' class=\"venobox\" id='button' data-autoplay=\"true\" data-vbtype=\"video\"><i class=\"fa fa-video-camera\"></i>  YouTube</a>".
						"</div>".
							"<div class='similar-info'>".
							"<br><br><br>"."<div class='primary-button'>".
									"<a href='tel:+39 349 839 5861'>Chiamata<i class='fa fa-euro-sign'></i></a>".
								"</div>".
							"</div>".
						"</div>".
					"</div>".
				"</div>".
			"</div>".
		"</div>".
	"</div>".
	"<section>".
		"<div class='more-details'>".
			"<div class='container'>".
				"<div class='row'>".
					"<div class='col-md-6'>".
						"<div class='item wow fadeInUp' data-wow-duration='0.5s'>".
							"<div class='sep-section-heading'>".
								"<h2>Più  <em>Descrizione</em></h2>".
							"</div>".
							"<p>"."<?php echo \$desc; ?>"."</p>".
						"</div>".
					"</div>".
					"<div class='col-md-6 wow fadeInUp' data-wow-duration='0.75s'>".
						"<div class='item'>".
							"<div class='sep-section-heading'>".
								"<h2>INFORMAZIONI <em>DI Contatto</em></h2>".
							"</div>".
							"<p>Puoi contattarci telefonicamente o via email!</p>".
							"<div class='contact-info'>".
								"<div class='row'>".
									"<div class='phone col-md-12 col-sm-6 col-xs-6'>".
										"<a href='tel:+39 349 839 5861'><i class='fa fa-phone'></i><span>+39 349 839 5861</span></a>".
									"</div>".
									"<div class='mail col-md-12 col-sm-6 col-xs-6'>".
										"<a href = 'mailto:macchine@autoclau.it'><i class='fa fa-envelope'></i><span>macchine@autoclau.it</span></a>".
									"</div>".
								"</div>".
							"</div>".
						"</div>".
					"</div>".
				"</div>".
			"</div>".
		"</div>".
	"</section>".
	"<section id=\"footer\">".
		"<div class=\"container\">".
			"<div class=\"row text-center text-xs-center text-sm-center text-md-center\">".
				"<div class=\"col-xs-12 col-sm-4 col-md-4\">".
				"<br><br>".
					"<h5>Menù</h5>".
					"<ul class=\"list-unstyled quick-links\">".
						"<li><a href=\"index.php\"><i class=\"fa fa-angle-double-right\"></i>Elenco Delle Auto</a></li>".
						"<li><a href=\"car_listing_sidebar.php\"><i class=\"fa fa-angle-double-right\"></i>Car Listing</a></li>".
						"<li><a href=\"contact_us.php\"><i class=\"fa fa-angle-double-right\"></i>Contatto</a></li>".
						"<li><a href='<?php echo \$redirect; ?>'><i class=\"fa fa-angle-double-right\"></i><?php echo \$state; ?></a>".
					"</ul>".
				"</div>".
				"<div class=\"col-xs-12 col-sm-4 col-md-4\">".
					"<br><br><br>".
					 "<div class=\"content\" style=\"sposition:absolute; width:100%; height:100%\">".
						"<center><img src=\"assets/images/logoo_f.png\" style=\"display: block; margin: 0 auto;\"></center>".
						"<br>".
					"</div>".
				"</div>".
				"<div class=\"col-xs-12 col-sm-4 col-md-4\">".
				"<br><br><br>".
					"<h5>Informazioni di contatto</h5>".
					"<ul class=\"list-unstyled quick-links\">".
						"<li><h2><i class=\"fa fa-map-marker\" aria-hidden=\"true\">  Lucca, Via Vittorio Bachelet 202, 55100, Italia</i></h2></li>".
						"<li><a href=\"tel:+39 349 839 5861\"><i class=\"fa fa fa-phone\"></i>+39 349 839 5861</a></li>".
						"<br>".
						"<li><a href=\"mailto:macchine@autoclau.it\"><i class=\"fa fa-envelope\"></i>macchine@autoclau.it</a></li>".
						"<br>".
					"</ul>".
				"</div>".
			"</div>".
			"<div class=\"row\">".
				"<div class=\"col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5\">".
					"<ul class=\"list-unstyled list-inline social text-center\">".
						"<li class=\"list-inline-item\"><a href=\"\"><i class=\"fa fa-facebook\"></i></a></li>".
						"<li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>".
						"<li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>".
						"<li class=\"list-inline-item\"><a href=\"#\"><i class=\"fa fa-google-plus\"></i></a></li>".
						"<li class=\"list-inline-item\"><a href=\"mailto:macchine@autoclau.it\" target=\"_blank\"><i class=\"fa fa-envelope\"></i></a></li>".
					"</ul>".
				"</div>".
				"<hr>".
			"</div>".
			"<div class=\"row\">".
				"<div class=\"col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white\">".
					"<p><u><a href=\"\">AutoClau</a></u> è una società a responsabilità limitata registrata fondata nel 2022.</p>".
					"<p class=\"h6\">©<a class=\"text-green ml-2\" href=\"\" target=\"_blank\">Tutti i diritti riservati..</a></p>".
				"</div>".
				"<hr>".
			"</div>".
		"</div>".
	"</section>".
	"<a href=\"https://api.whatsapp.com/send?phone=+393498395861&text=Ciao%21%20Voglio%20comprare%20una%20macchina%20!\" class=\"float\" target=\"_blank\">".
"<i class=\"fa fa-whatsapp my-float\"></i>".
"</a>".
	 "<script type=\"text/javascript\" src=\"jquery/jquery-3.6.0.min.js\"></script>".
     "<script type=\"text/javascript\" src=\"venobox/venobox.min.js\"></script>".
		"<script>".
            "$(document).ready(function(){".
                "$('.venobox').venobox({".
                    "closeColor: '#f4f4f4',".
                    "spinColor: '#f4f4f4',".
                    "arrowsColor: '#f4f4f4',".
                    "closeBackground: '#17191D',".
                    "overlayColor: 'rgba(23,25,29,0.8)'".
                "});". 
            "});".
			 "var show = document.getElementById(\"show_hide\").value;".
			 "var x = document.getElementById(\"hide\");".		 
			 "if (show === \"0\") {".
             "x.style.display = \"none\";".
  "}".		
        "</script>".
	"<!-- Slider Pro Js -->".
	"<script src='assets/js/sliderpro.min.js'></script>".
	"<!-- Slick Slider Js -->".
	"<script src='assets/js/slick.js'></script>".
	"<!-- Owl Carousel Js -->".
    "<script src='assets/js/owl.carousel.min.js'></script>".
	"<!-- Boostrap Js -->".
    "<script src='assets/js/bootstrap.min.js'></script>".
    "<!-- Boostrap Js -->".
    "<script src='assets/js/wow.animation.js'></script>".
	"<!-- Custom Js -->".
    "<script src='assets/js/custom.js'></script>".
"</body>".
"</html>";
$f=fopen($name,"w");
$code=fwrite($f,$strOut);
fclose($f);



}
else{
	$sql = "DELETE FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sters ok
}
else{
	echo "Fail to delete item!";
}

$sql = "DELETE FROM images WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sters ok
}
else{
	echo "Fail to delete item!";
}

$sql = "DELETE FROM img_idx WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	
}
else{
	echo "Fail to delete item!";
}
	
if($v1){
	$ms1="Eroare la adaugarea informatii in baza de date!<br>";
    }
if($v2){
	$ms2="Eroare la baza de date!<br>";
    }
if($v3){
	
    }
if($v6){
	$ms6="Se pare ca ati selectat un fisier care nu are extensia .jpg .png .jpeg!Incearca din nou<br>";
    }
	
	header("location:error.php?ms1=$ms1&ms2=$ms2&ms3=$ms3&ms4=$ms4&ms5=$ms5&ms6=$ms6");
}

mysqli_close($connect);
}

header("location:success.html");
 
}
  ob_end_flush();
// Close connection


?>
 