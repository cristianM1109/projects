<?php 
require_once("conection.php");
$connect;

$id=$_GET["id"];
$err=$_GET["err"];

$sql = "SELECT titlu FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if ($result->num_rows > 0){
	$row = $result->fetch_assoc();
	
$titlu=$row['titlu'];
}


$active="";
$text="";


$sql1 = "SELECT path FROM images WHERE id='$id' ORDER BY path ASC";
$sql2 = "SELECT path FROM tumb WHERE id='$id' ORDER BY path ASC";
$photos="";
		$result1 = mysqli_query($connect,$sql1);
		$result2 = mysqli_query($connect,$sql2);
		   if (($result1->num_rows > 0) && ($result2->num_rows > 0)){
			    while(($row1 = $result1->fetch_assoc()) && ($row2 = $result2->fetch_assoc())) {
					
					$path=$row1["path"];
					$path2=$row2["path"];
					
					$sql = "SELECT path FROM img_idx WHERE path='$path2'";
					$result = $connect->query($sql);
                    if ($result->num_rows > 0){
	                $active="danger";
					$text="Profil";
						
					}
					else{
                        $text="Seteaza profil"; 
						$active="success";
					}
				
				    
                    					
					$photos.= "<li class=\"col-xs-6 col-sm-4 col-md-2 col-lg-2\" >".
                              "<a href='del_pic.php?name=$path&id=$id' class=\"image-fav\">".
                              "<img class=\"img-responsive\" src='tumb/".$path2."'>".
                              "</a>".
                              "</li>".
							  "<center><a href=\"update_pro.php?id=$id&name=$path\" class=\"btn btn-$active\" role=\"button\"><i class=\"fa fa-user\"></i>  $text</a></center><br>";		
		   }
		   }
		   
		   
$sql = "SELECT page FROM anunt WHERE id='$id'";
$result = $connect->query($sql);

if($result){
	//sa gasit linia din tabel cu id=id
}
else{
	$nofind_err=1;
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $page_addr=$row["page"];
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo $titlu; ?></title>
		<link rel='icon' href='assets/images/logoo.ico'>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/lightgallery/1.3.9/css/lightgallery.min.css" rel="stylesheet">
        
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		     <link rel='stylesheet' href='style.css'>
			 <style>
		
		body{
			background-color:#333333;
			}
		h2{
			color:#fff;
			margin-bottom:40px;
			text-align:center;
			font-weight:100;
			}
		
		
		
		
		
		</style>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    </head>
    <body class="home">
        <div class="container" style="margin-top:40px;">
            <h2>Click pe poza pentru a sterge.</h2>
			<h2 style="color:red;"><?php echo $err; ?><h2>
            <div class="demo-gallery">
                <ul id="lightgallery" class="list-unstyled row">
                   <?php echo $photos; ?>
                </ul>
            </div>
			<center><a href="galery.php?id=<?php echo $id; ?>" class="btn btn-info" role="button"><i class="fa fa-angle-double-left"></i>  Inapoi la galerie</a></center><br>
        </div>
		<script src="galery.js"></script>
        
    </body>    
</html>